﻿using DiscUtils.Fat;
using Internationale.VKP.Compound;
using Internationale.VKP.Image.Sections;
using Internationale.VKP.May;
using Internationale.VKP.May.Machine;
using Internationale.VKP.Serializer.Sai;
using Mono.Cecil;

class Program
{
    static void Main(string[] args)
    {
        AssemblyDefinition definition = AssemblyDefinition.ReadAssembly("H:\\Projects\\CSharp\\New\\TestLib\\Core\\bin\\Debug\\netstandard1.0\\Core.dll");

        Compound compound = new Compound();
        compound.Load(definition);

        Internationale.VKP.Image.Image image = new Internationale.VKP.Image.Image(definition);
        image.Load(compound);

        // List<RegisterTranslator> compilers = new List<RegisterTranslator>();
        //
        // foreach (var method in compound.MethodDefinitions)
        // {
        //     if (method.Executable != null)
        //     {
        //         RegisterTranslator registerTranslator = new RegisterTranslator();
        //         registerTranslator.Compile(method,compound);
        //         Optimizer optimizer = new Optimizer(registerTranslator);
        //         optimizer.OptimizeMoves();
        //         compilers.Add(registerTranslator);
        //         RiscGenerator generator = new RiscGenerator(registerTranslator);
        //         generator.Compile();
        //     }
        // }

        SaiSerializer saiSerializer = new SaiSerializer();
        byte[] value = saiSerializer.Serialize(image);

        File.WriteAllBytes("H:\\Projects\\CC++\\MarxVm\\System.vkp", value);
        File.WriteAllBytes("H:\\Projects\\CC++\\ltos\\System.vkp", value);
        //MemoryStream stream = new MemoryStream(File.ReadAllBytes("H:\\Projects\\CSharp\\New\\VKPFormat\\disk.img"));

        // using (FatFileSystem system = new FatFileSystem(stream))
        // {
        //     using (Stream fileStream = system.OpenFile("CORLIBMX", FileMode.CreateNew))
        //     {
        //         BinaryWriter writer = new BinaryWriter(fileStream);
        //         writer.Write(value);
        //     }
        // }

        //File.WriteAllBytes("H:\\Projects\\CC++\\Duo\\disk.img", stream.ToArray());
    }
}