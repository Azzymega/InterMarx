﻿namespace Internationale.VKP.Serializer.Attributes;

public class InlineAttribute : Attribute
{
    
}