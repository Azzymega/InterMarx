﻿namespace Internationale.VKP.Serializer.Attributes;

public class IgnoreAttribute : Attribute
{
    
}