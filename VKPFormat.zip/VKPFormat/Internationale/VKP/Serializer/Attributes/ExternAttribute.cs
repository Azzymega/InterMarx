﻿namespace Internationale.VKP.Serializer.Attributes;

public class ExternAttribute : Attribute
{
    
}