﻿namespace Internationale.VKP.Serializer;

public abstract class Serializer
{
    public abstract byte[] Serialize(Image.Image image);
}