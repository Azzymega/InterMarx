﻿using System.Reflection;
using System.Text;
using Internationale.VKP.Image;
using Internationale.VKP.Image.Code;
using Internationale.VKP.Image.Sections;
using Internationale.VKP.Serializer.Attributes;
using Attribute = Internationale.VKP.Image.Sections.Attribute;
using Image_Sections_Type = Internationale.VKP.Image.Sections.Type;
using Sections_Type = Internationale.VKP.Image.Sections.Type;
using Type = Internationale.VKP.Image.Sections.Type;
using VKP_Image_Sections_Type = Internationale.VKP.Image.Sections.Type;

namespace Internationale.VKP.Serializer.Sai;

public class SaiSerializer : Serializer
{
    private Strings Table { get; set; }

    public override byte[] Serialize(Image.Image image)
    {
        MemoryStream stream = new MemoryStream();
        BinaryWriter writer = new BinaryWriter(stream);
        Table = image.Table; // TODO FIX BAD API
        
        Fill(image);
        
        writer.Write(image.Magic);
        writer.Write(image.Sections.Count);
        
        foreach (var imageSection in image.Sections)
        {
            Serialize(imageSection, writer, stream, image);
        }

        return stream.ToArray();
    }

    private void Fill(Image.Image image)
    {
        for (int i = 2; i < image.Sections.Count; i++)
        {
            Fill(image.Sections[i]);
        }
    }
    private void Fill(object value)
    {
        foreach (var propertyInfo in value.GetType().GetProperties())
        {
            if (!System.Attribute.IsDefined(propertyInfo,typeof(IgnoreAttribute)))
            {
                if (propertyInfo.PropertyType == typeof(string))
                {
                    if (!System.Attribute.IsDefined(propertyInfo,typeof(InlineAttribute)))
                    {
                        Table.Register(propertyInfo.GetValue(value).ToString());
                    }
                }                
            }
        }
    }
    
    private void Serialize(object value, BinaryWriter writer, MemoryStream stream, Image.Image image)
    {
        int initialPosition = (int)writer.BaseStream.Position;
        writer.Write(initialPosition);
        foreach (var propertyInfo in value.GetType().GetProperties())
        {
            if (!System.Attribute.IsDefined(propertyInfo,typeof(IgnoreAttribute)))
            {
                if (propertyInfo.PropertyType == typeof(string))
                {
                    if (System.Attribute.IsDefined(propertyInfo,typeof(InlineAttribute)))
                    {
                        string target = propertyInfo.GetValue(value).ToString();
                        writer.Write(target.Length);
                        writer.Write(Encoding.UTF8.GetBytes(target));
                    }
                    else
                    {
                        writer.Write(Table.Register(propertyInfo.GetValue(value).ToString()));
                    }
                }

                else if (propertyInfo.PropertyType == typeof(List<string>))
                {
                    if (System.Attribute.IsDefined(propertyInfo,typeof(ExternAttribute)))
                    {
                        List<string> target = (List<string>)propertyInfo.GetValue(value);
                        writer.Write(target.Count);
                        foreach (var info in target)
                        {
                            writer.Write(Table.Find(info));
                        } 
                    }
                    else
                    {
                        List<string> target = (List<string>)propertyInfo.GetValue(value);
                        writer.Write(target.Count);
                        foreach (var info in target)
                        {
                            writer.Write(info.Length);
                            writer.Write(Encoding.UTF8.GetBytes(info));
                        }                        
                    }
                }

                else if (propertyInfo.PropertyType == typeof(int)) 
                {
                    writer.Write((int)propertyInfo.GetValue(value));
                }
                
                else if (propertyInfo.PropertyType == typeof(List<int>))
                {
                    List<int> target = (List<int>)propertyInfo.GetValue(value);
                    writer.Write(target.Count);
                    foreach (var i in target)
                    {
                        writer.Write(i);
                    }
                }
                
                else if (propertyInfo.PropertyType == typeof(Characteristics))
                {
                    Characteristics info = (Characteristics)propertyInfo.GetValue(value);
                    writer.Write((int)info);
                }

                else if (propertyInfo.PropertyType == typeof(SectionType))
                {
                    writer.Write((int)propertyInfo.GetValue(value));
                }

                else if (propertyInfo.PropertyType == typeof(List<SectionType>))
                {
                    List<SectionType> target = (List<SectionType>)propertyInfo.GetValue(value);
                    writer.Write(target.Count);
                    foreach (var sectionType in target)
                    {
                        writer.Write((int)sectionType);
                    }
                }

                else if (propertyInfo.PropertyType == typeof(List<Section>))
                {
                    List<Section> sections = (List<Section>)propertyInfo.GetValue(value);
                    writer.Write(sections.Count);
                    foreach (var section in sections)
                    {
                        writer.Write(image.IndexOf(section));
                    }
                }
                
                else if (propertyInfo.PropertyType == typeof(List<VKP_Image_Sections_Type>))
                {
                    List<VKP_Image_Sections_Type> sections = (List<VKP_Image_Sections_Type>)propertyInfo.GetValue(value);
                    writer.Write(sections.Count);
                    foreach (var section in sections)
                    {
                        writer.Write(image.IndexOf(section));
                    }
                }

                else if (propertyInfo.PropertyType == typeof(List<byte>))
                {
                    List<byte> bytes = (List<byte>)propertyInfo.GetValue(value);
                    writer.Write(bytes.Count);
                    writer.Write(bytes.ToArray());
                }

                else if (propertyInfo.PropertyType == typeof(VKP_Image_Sections_Type))
                {
                    writer.Write(image.IndexOf((VKP_Image_Sections_Type)propertyInfo.GetValue(value)));
                }
                
                else if (propertyInfo.PropertyType == typeof(Attribute))
                {
                    writer.Write(image.IndexOf((Attribute)propertyInfo.GetValue(value)));
                }
                
                else if (propertyInfo.PropertyType == typeof(Section))
                {
                    writer.Write(image.IndexOf((Section)propertyInfo.GetValue(value)));
                }
                
                else if (propertyInfo.PropertyType == typeof(Executable))
                {
                    writer.Write(image.IndexOf((Executable)propertyInfo.GetValue(value)));
                }
                
                else if (propertyInfo.PropertyType == typeof(Field))
                {
                    writer.Write(image.IndexOf((Field)propertyInfo.GetValue(value)));
                }
                
                else if (propertyInfo.PropertyType == typeof(HandlerType))
                {
                    writer.Write((int)propertyInfo.GetValue(value));
                }
                
                else if (propertyInfo.PropertyType == typeof(Method))
                {
                    writer.Write(image.IndexOf((Method)propertyInfo.GetValue(value)));
                }

                else
                {
                    throw new Exception("Unknown type! " + propertyInfo);
                }
            }
        }

        int size = (int)(writer.BaseStream.Position - initialPosition);
        long end = writer.BaseStream.Position;
        writer.BaseStream.Position = initialPosition;
        writer.Write(size);
        writer.BaseStream.Position = end;
    }
}