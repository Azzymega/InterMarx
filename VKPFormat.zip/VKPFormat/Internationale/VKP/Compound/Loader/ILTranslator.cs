﻿using Internationale.VKP.Image;
using Internationale.VKP.Image.Code;
using Internationale.VKP.Image.Sections;
using Mono.Cecil;
using Mono.Cecil.Cil;
using Mono.Cecil.Rocks;

namespace Internationale.VKP.Compound.Loader;

public class ILTranslator
{
    public Method Target { get; set; }
    public MethodDefinition Definition { get; set; }
    public Compound Directory { get; set; }
    public BranchMachine BranchMachine { get; set; }

    private Instruction Current;

    public ILTranslator(Compound directory, MethodDefinition definition, Method target)
    {
        Directory = directory;
        Definition = definition;
        Target = target;
    }

    private void Nuke()
    {
        throw new Exception(Current.ToString());
    }

    private void Add(Bytecode bytecode)
    {
        Target.Executable.Bytecodes.Add(bytecode);
        Target.Executable.Image.Add((byte)bytecode);
        BranchMachine.Load(Current, Target.Executable.Image.Count - 1);
    }

    private int Register(Section section)
    {
        if (Target.Executable.Pool.IndexOf(section) != -1)
        {
            return Target.Executable.Pool.IndexOf(section);
        }
        Target.Executable.Pool.Add(section);
        Target.Executable.Types.Add(section.GetType());
        return Target.Executable.Pool.Count - 1;
    }

    private int Register(string value)
    {
        Target.Executable.StringsTable.Add(value);
        Directory.Table.Register(value);
        return Target.Executable.StringsTable.Count - 1;
    }

    private void Immediate(int value)
    {
        Target.Executable.Image.AddRange(BitConverter.GetBytes(value));
    }

    private void Immediate(float value)
    {
        Target.Executable.Image.AddRange(BitConverter.GetBytes(value));
    }

    private void Immediate(double value)
    {
        Target.Executable.Image.AddRange(BitConverter.GetBytes(value));
    }

    private void Immediate(long value)
    {
        Target.Executable.Image.AddRange(BitConverter.GetBytes(value));
    }


    private void SaveBranch()
    {
        BranchMachine.RegisterBranch(Current, Target.Executable.Image.Count);
        Immediate(0);
    }


    private void LoadIntOpcode(Mono.Cecil.Cil.Code bytecode)
    {
        int value = bytecode - Mono.Cecil.Cil.Code.Ldc_I4_M1;
        value -= 1;
        Add(Bytecode.OpLoadImmediateInt32);
        Immediate(value);
    }

    private void LocalLoadOpcode(Mono.Cecil.Cil.Code bytecode)
    {
        int value = bytecode - Mono.Cecil.Cil.Code.Ldloc_0;
        Add(Bytecode.OpLoadLocal);
        Immediate(value);
    }

    private void ArgumentLoadOpcode(Mono.Cecil.Cil.Code bytecode)
    {
        int value = bytecode - Mono.Cecil.Cil.Code.Ldarg_0;
        Add(Bytecode.OpLoadArgument);
        Immediate(value);
    }

    private void LocalStoreOpcode(Mono.Cecil.Cil.Code bytecode)
    {
        int value = bytecode - Mono.Cecil.Cil.Code.Stloc_0;
        Add(Bytecode.OpStoreLocal);
        Immediate(value);
    }

    public void CompileHandlers()
    {
        foreach (var handler in Definition.Body.ExceptionHandlers)
        {
            Handler target = new Handler(Directory, handler, Target.Executable, BranchMachine);
            Target.Executable.Handlers.Add(target);
            Directory.Register(target);
        }
    }

    public void Compile()
    {
        Executable executable = new Executable();
        Target.Executable = executable;
        executable.Owner = Target;
        Directory.Register(executable);
        BranchMachine = new BranchMachine(executable.Image);

        foreach (var variable in Target.Definition.Body.Variables)
        {
            executable.Variables.Add(Directory.Get(variable.VariableType));
        }

        foreach (var instruction in Definition.Body.Instructions)
        {
            Current = instruction;
            switch (instruction.OpCode.Code)
            {
                case Mono.Cecil.Cil.Code.Add:
                {
                    Add(Bytecode.OpAdd);
                    break;
                }
                case Mono.Cecil.Cil.Code.Sub:
                {
                    Add(Bytecode.OpSub);
                    break;
                }
                case Mono.Cecil.Cil.Code.Mul:
                {
                    Add(Bytecode.OpMu);
                    break;
                }
                case Mono.Cecil.Cil.Code.Div:
                {
                    Add(Bytecode.OpDiv);
                    break;
                }
                case Mono.Cecil.Cil.Code.Rem:
                {
                    Add(Bytecode.OpRem);
                    break;
                }
                case Mono.Cecil.Cil.Code.Neg:
                {
                    Add(Bytecode.OpNeg);
                    break;
                }
                
                case Mono.Cecil.Cil.Code.And:
                {
                    Add(Bytecode.OpAnd);
                    break;
                }
                case Mono.Cecil.Cil.Code.Or:
                {
                    Add(Bytecode.OpOr);
                    break;
                }
                case Mono.Cecil.Cil.Code.Xor:
                {
                    Add(Bytecode.OpXor);
                    break;
                }
                case Mono.Cecil.Cil.Code.Not:
                {
                    Add(Bytecode.OpNot);
                    break;
                }
                case Mono.Cecil.Cil.Code.Shl:
                {
                    Add(Bytecode.OpShiftLeft);
                    break;
                }
                case Mono.Cecil.Cil.Code.Shr:
                {
                    Add(Bytecode.OpShiftRight);
                    break;
                }


                case Mono.Cecil.Cil.Code.Nop:
                {
                    Add(Bytecode.OpNoOperation);
                    break;
                }
                case Mono.Cecil.Cil.Code.Break:
                {
                    Add(Bytecode.OpBreakpoint);
                    break;
                }


                case Mono.Cecil.Cil.Code.Dup:
                {
                    Add(Bytecode.OpDup);
                    break;
                }
                case Mono.Cecil.Cil.Code.Pop:
                {
                    Add(Bytecode.OpPop);
                    break;
                }


                case Mono.Cecil.Cil.Code.Conv_I1:
                {
                    Add(Bytecode.OpConvertI8);
                    break;
                }
                case Mono.Cecil.Cil.Code.Conv_U2:
                case Mono.Cecil.Cil.Code.Conv_I2:
                {
                    Add(Bytecode.OpConvertI16);
                    break;
                }
                case Mono.Cecil.Cil.Code.Conv_U4:
                case Mono.Cecil.Cil.Code.Conv_I4:
                {
                    Add(Bytecode.OpConvertI32);
                    break;
                }
                case Mono.Cecil.Cil.Code.Conv_U:
                case Mono.Cecil.Cil.Code.Conv_I:
                {
                    Add(Bytecode.OpConvertIntPtr);
                    break;
                }
                case Mono.Cecil.Cil.Code.Conv_I8:
                {
                    Add(Bytecode.OpConvertI64);
                    break;
                }
                case Mono.Cecil.Cil.Code.Conv_R4:
                {
                    Add(Bytecode.OpConvertFloat);
                    break;
                }
                case Mono.Cecil.Cil.Code.Conv_R8:
                {
                    Add(Bytecode.OpConvertDouble);
                    break;
                }

                case Mono.Cecil.Cil.Code.Ldstr:
                {
                    Add(Bytecode.OpLoadString);
                    Immediate(Register(instruction.Operand.ToString()));
                    break;
                }

                case Mono.Cecil.Cil.Code.Ldsfld:
                {
                    Add(Bytecode.OpLoadStaticField);
                    Immediate(Register(Directory.Get((FieldReference)instruction.Operand)));
                    break;
                }
                case Mono.Cecil.Cil.Code.Ldfld:
                {
                    Add(Bytecode.OpLoadValueField);
                    Immediate(Register(Directory.Get((FieldReference)instruction.Operand)));

                    break;
                }
                case Mono.Cecil.Cil.Code.Ldloca_S:
                case Mono.Cecil.Cil.Code.Ldloca:
                {
                    Add(Bytecode.OpLoadLocalVariableAddress);
                    Immediate(((VariableDefinition)Current.Operand).Index);

                    break;
                }
                case Code.Ldelema:
                {
                    Add(Bytecode.OpLoadAddressOfArrayElement);
                    Immediate(Register(Directory.Get((TypeReference)instruction.Operand)));
                    break;
                }
                case Mono.Cecil.Cil.Code.Ldarga_S:
                {
                    Add(Bytecode.OpLoadArgumentAddress);
                    Immediate(((ParameterDefinition)Current.Operand).Index);

                    break;
                }
                case Mono.Cecil.Cil.Code.Ldarga:
                {
                    Add(Bytecode.OpLoadArgumentAddress);
                    Immediate(((ParameterDefinition)Current.Operand).Index);

                    break;
                }
                case Mono.Cecil.Cil.Code.Ldflda:
                {
                    Add(Bytecode.OpLoadValueFieldAddress);
                    Immediate(Register(Directory.Get((FieldReference)instruction.Operand)));

                    break;
                }
                case Mono.Cecil.Cil.Code.Stfld:
                {
                    Add(Bytecode.OpStoreValueField);
                    Immediate(Register(Directory.Get((FieldReference)instruction.Operand)));

                    break;
                }
                case Mono.Cecil.Cil.Code.Stsfld:
                {
                    Add(Bytecode.OpStoreStaticField);
                    Immediate(Register(Directory.Get((FieldReference)instruction.Operand)));
                    break;
                }

                case Mono.Cecil.Cil.Code.Ldind_I1:
                {
                    Add(Bytecode.OpLoadValueFromPointer);
                    Immediate(Register(Directory.Get("System.Byte")));
                    break; 
                }
                
                case Mono.Cecil.Cil.Code.Ldind_U2:
                case Mono.Cecil.Cil.Code.Ldind_I2:
                {
                    Add(Bytecode.OpLoadValueFromPointer);
                    Immediate(Register(Directory.Get("System.Int16")));
                    break; 
                }
                
                case Mono.Cecil.Cil.Code.Ldind_I8:
                {
                    Add(Bytecode.OpLoadValueFromPointer);
                    Immediate(Register(Directory.Get("System.Int64")));
                    break; 
                }
                
                case Mono.Cecil.Cil.Code.Ldind_R8:
                {
                    Add(Bytecode.OpLoadValueFromPointer);
                    Immediate(Register(Directory.Get("System.Double")));
                    break; 
                }
                
                case Mono.Cecil.Cil.Code.Ldind_R4:
                {
                    Add(Bytecode.OpLoadValueFromPointer);
                    Immediate(Register(Directory.Get("System.Single")));
                    break; 
                }
                
                case Mono.Cecil.Cil.Code.Ldind_Ref:
                {
                    Add(Bytecode.OpLoadValueFromPointer);
                    Immediate(Register(Directory.Get("System.Object")));
                    break; 
                }
                
                case Mono.Cecil.Cil.Code.Ldind_I:
                {
                    Add(Bytecode.OpLoadValueFromPointer);
                    Immediate(Register(Directory.Get("System.IntPtr")));
                    break; 
                }

                case Code.Stind_I4:
                {
                    Add(Bytecode.OpStoreValueToPointer);
                    Immediate(Register(Directory.Get("System.Int32")));
                    break;
                }

                case Code.Stind_I1:
                {
                    Add(Bytecode.OpStoreValueToPointer);
                    Immediate(Register(Directory.Get("System.Byte")));
                    break;
                }
                
                case Code.Stind_I2:
                {
                    Add(Bytecode.OpStoreValueToPointer);
                    Immediate(Register(Directory.Get("System.Int16")));
                    break;
                }
                
                case Code.Stind_R4:
                {
                    Add(Bytecode.OpStoreValueToPointer);
                    Immediate(Register(Directory.Get("System.Single")));
                    break;
                }
                
                case Code.Stind_R8:
                {
                    Add(Bytecode.OpStoreValueToPointer);
                    Immediate(Register(Directory.Get("System.Double")));
                    break;
                }
                
                case Code.Stind_Ref:
                {
                    Add(Bytecode.OpStoreValueToPointer);
                    Immediate(Register(Directory.Get("System.Object")));
                    break;
                }
                
                case Code.Stind_I:
                {
                    Add(Bytecode.OpStoreValueToPointer);
                    Immediate(Register(Directory.Get("System.IntPtr")));
                    break;
                }
                
                case Mono.Cecil.Cil.Code.Ldobj:
                    Add(Bytecode.OpLoadValueFromPointer);
                    Immediate(Register(Directory.Get((TypeReference)instruction.Operand)));
                    break; 
                
                case Mono.Cecil.Cil.Code.Ldind_I4:
                    Add(Bytecode.OpLoadValueFromPointer);
                    Immediate(Register(Directory.Get("System.Int32")));
                    break;

                case Mono.Cecil.Cil.Code.Ldarg_0:
                case Mono.Cecil.Cil.Code.Ldarg_1:
                case Mono.Cecil.Cil.Code.Ldarg_2:
                case Mono.Cecil.Cil.Code.Ldarg_3:
                    ArgumentLoadOpcode(Current.OpCode.Code);
                    break;

                case Mono.Cecil.Cil.Code.Ldarg_S:
                case Mono.Cecil.Cil.Code.Ldarg:
                    Add(Bytecode.OpLoadArgument);
                    Immediate(((ParameterDefinition)Current.Operand).Sequence);
                    break;

                case Mono.Cecil.Cil.Code.Stloc_0:
                case Mono.Cecil.Cil.Code.Stloc_1:
                case Mono.Cecil.Cil.Code.Stloc_2:
                case Mono.Cecil.Cil.Code.Stloc_3:
                    LocalStoreOpcode(Current.OpCode.Code);
                    break;

                case Mono.Cecil.Cil.Code.Stloc_S:
                case Mono.Cecil.Cil.Code.Stloc:
                    Add(Bytecode.OpStoreLocal);
                    Immediate(((VariableDefinition)Current.Operand).Index);
                    break;

                case Mono.Cecil.Cil.Code.Ldloc_0:
                case Mono.Cecil.Cil.Code.Ldloc_1:
                case Mono.Cecil.Cil.Code.Ldloc_2:
                case Mono.Cecil.Cil.Code.Ldloc_3:
                    LocalLoadOpcode(Current.OpCode.Code);
                    break;

                case Mono.Cecil.Cil.Code.Ldloc_S:
                case Mono.Cecil.Cil.Code.Ldloc:
                    Add(Bytecode.OpLoadLocal);
                    Immediate(((VariableDefinition)Current.Operand).Index);
                    break;

                case Mono.Cecil.Cil.Code.Starg_S:
                case Mono.Cecil.Cil.Code.Starg:
                    Add(Bytecode.OpStoreArgument);
                    Immediate(((ParameterDefinition)Current.Operand).Index);
                    break;

                case Mono.Cecil.Cil.Code.Ldnull:
                    Add(Bytecode.OpLoadNull);
                    break;

                case Mono.Cecil.Cil.Code.Ldc_I4_M1:
                case Mono.Cecil.Cil.Code.Ldc_I4_0:
                case Mono.Cecil.Cil.Code.Ldc_I4_1:
                case Mono.Cecil.Cil.Code.Ldc_I4_2:
                case Mono.Cecil.Cil.Code.Ldc_I4_3:
                case Mono.Cecil.Cil.Code.Ldc_I4_4:
                case Mono.Cecil.Cil.Code.Ldc_I4_5:
                case Mono.Cecil.Cil.Code.Ldc_I4_6:
                case Mono.Cecil.Cil.Code.Ldc_I4_7:
                case Mono.Cecil.Cil.Code.Ldc_I4_8:
                    LoadIntOpcode(instruction.OpCode.Code);
                    break;

                case Mono.Cecil.Cil.Code.Ldc_I4_S:
                    Add(Bytecode.OpLoadImmediateInt32);
                    Immediate((sbyte)Current.Operand);
                    break;

                case Mono.Cecil.Cil.Code.Ldc_I4:
                    Add(Bytecode.OpLoadImmediateInt32);
                    Immediate((int)Current.Operand);
                    break;

                case Mono.Cecil.Cil.Code.Ldc_I8:
                    Add(Bytecode.OpLoadImmediateInt64);
                    Immediate((long)Current.Operand);
                    break;

                case Mono.Cecil.Cil.Code.Ldc_R4:
                    Add(Bytecode.OpLoadImmediateFloat);
                    Immediate((float)Current.Operand);
                    break;

                case Mono.Cecil.Cil.Code.Ldc_R8:
                    Add(Bytecode.OpLoadImmediateDouble);
                    Immediate((double)Current.Operand);
                    break;

                case Mono.Cecil.Cil.Code.Br:
                case Mono.Cecil.Cil.Code.Br_S:
                    Add(Bytecode.OpBranch);
                    SaveBranch();
                    break;

                case Mono.Cecil.Cil.Code.Brfalse:
                case Mono.Cecil.Cil.Code.Brfalse_S:
                    Add(Bytecode.OpBranchIfZero);
                    SaveBranch();
                    break;

                case Mono.Cecil.Cil.Code.Brtrue:
                case Mono.Cecil.Cil.Code.Brtrue_S:
                    Add(Bytecode.OpBranchIfNonZero);
                    SaveBranch();
                    break;

                case Mono.Cecil.Cil.Code.Beq:
                case Mono.Cecil.Cil.Code.Beq_S:
                    Add(Bytecode.OpBranchIfEquals);
                    SaveBranch();
                    break;

                case Mono.Cecil.Cil.Code.Bne_Un:
                case Mono.Cecil.Cil.Code.Bne_Un_S:
                    Add(Bytecode.OpBranchIfUnequalUnordered);
                    SaveBranch();
                    break;

                case Mono.Cecil.Cil.Code.Bge:
                case Mono.Cecil.Cil.Code.Bge_S:
                    Add(Bytecode.OpBranchIfGreaterOrEqual);
                    SaveBranch();
                    break;

                case Mono.Cecil.Cil.Code.Bgt:
                case Mono.Cecil.Cil.Code.Bgt_S:
                    Add(Bytecode.OpBranchIfGreater);
                    SaveBranch();
                    break;

                case Mono.Cecil.Cil.Code.Ble:
                case Mono.Cecil.Cil.Code.Ble_S:
                    Add(Bytecode.OpBranchIfLessOrEqual);
                    SaveBranch();
                    break;

                case Mono.Cecil.Cil.Code.Blt:
                case Mono.Cecil.Cil.Code.Blt_S:
                    Add(Bytecode.OpBranchIfLess);
                    SaveBranch();
                    break;

                case Mono.Cecil.Cil.Code.Call:
                    Add(Bytecode.OpCall);
                    Immediate(Register(Directory.Get((MethodReference)instruction.Operand)));
                    break;

                case Mono.Cecil.Cil.Code.Callvirt:
                    Add(Bytecode.OpVirtualCall);
                    Immediate(Register(Directory.Get((MethodReference)instruction.Operand)));
                    break;

                case Mono.Cecil.Cil.Code.Ret:
                    Add(Bytecode.OpReturn);
                    break;

                case Mono.Cecil.Cil.Code.Isinst:
                    Add(Bytecode.OpIsInstance);
                    Immediate(Register(Directory.Get((TypeReference)instruction.Operand)));
                    break;

                case Mono.Cecil.Cil.Code.Castclass:
                    Add(Bytecode.OpCastClass);
                    Immediate(Register(Directory.Get((TypeReference)instruction.Operand)));
                    break;

                case Mono.Cecil.Cil.Code.Ceq:
                    Add(Bytecode.OpPushOneIfEqual);
                    break;

                case Mono.Cecil.Cil.Code.Cgt:
                    Add(Bytecode.OpPushOneIfGreater);
                    break;

                case Mono.Cecil.Cil.Code.Clt:
                    Add(Bytecode.OpPushOneIfLower);
                    break;

                case Mono.Cecil.Cil.Code.Clt_Un:
                    Add(Bytecode.OpPushOneIfLowerUn);
                    break;

                case Mono.Cecil.Cil.Code.Cgt_Un:
                    Add(Bytecode.OpPushOneIfGreaterUn);
                    break;

                case Mono.Cecil.Cil.Code.Leave:
                case Mono.Cecil.Cil.Code.Leave_S:
                    Add(Bytecode.OpLeaveException);
                    SaveBranch();
                    break;
                
                case Mono.Cecil.Cil.Code.Box:
                    Add(Bytecode.OpBox);
                    Immediate(Register(Directory.Get((TypeReference)instruction.Operand)));
                    break;

                case Mono.Cecil.Cil.Code.Unbox_Any:
                    Add(Bytecode.OpUnboxToValue);
                    Immediate(Register(Directory.Get((TypeReference)instruction.Operand)));
                    break;
                case Mono.Cecil.Cil.Code.Unbox:
                    Add(Bytecode.OpUnboxToPointer);
                    Immediate(Register(Directory.Get((TypeReference)instruction.Operand)));
                    break;

                case Mono.Cecil.Cil.Code.Rethrow:
                    Add(Bytecode.OpRethrowException);
                    break;

                case Mono.Cecil.Cil.Code.Throw:
                    Add(Bytecode.OpThrowException);
                    break;

                case Mono.Cecil.Cil.Code.Endfinally:
                    Add(Bytecode.OpEndFinallyException);
                    break;

                case Mono.Cecil.Cil.Code.Newarr:
                    Add(Bytecode.OpNewArray);
                    Immediate(Register(Directory.Get(((TypeReference)instruction.Operand))));
                    Immediate(Register(Directory.Get(((TypeReference)instruction.Operand).MakeArrayType())));
                    break;

                case Mono.Cecil.Cil.Code.Ldelem_I1:
                case Mono.Cecil.Cil.Code.Ldelem_U1:
                    Add(Bytecode.OpLoadInt8FromArray);
                    break;

                case Mono.Cecil.Cil.Code.Ldelem_I2:
                case Mono.Cecil.Cil.Code.Ldelem_U2:
                    Add(Bytecode.OpLoadInt16FromArray);
                    break;

                case Mono.Cecil.Cil.Code.Ldelem_I4:
                case Mono.Cecil.Cil.Code.Ldelem_U4:
                    Add(Bytecode.OpLoadInt32FromArray);
                    break;

                case Mono.Cecil.Cil.Code.Ldelem_I8:
                    Add(Bytecode.OpLoadInt64FromArray);
                    break;

                case Mono.Cecil.Cil.Code.Ldelem_I:
                    Add(Bytecode.OpLoadNativeIntFromArray);
                    break;

                case Mono.Cecil.Cil.Code.Ldelem_R4:
                    Add(Bytecode.OpLoadFloatFromArray);
                    break;

                case Mono.Cecil.Cil.Code.Ldelem_R8:
                    Add(Bytecode.OpLoadDoubleFromArray);
                    break;

                case Mono.Cecil.Cil.Code.Ldelem_Any:
                case Mono.Cecil.Cil.Code.Ldelem_Ref:
                    Add(Bytecode.OpLoadObjectFromArray);
                    break;

                case Mono.Cecil.Cil.Code.Ldlen:
                    Add(Bytecode.OpLoadArrayLength);
                    break;

                case Mono.Cecil.Cil.Code.Stelem_I1:
                    Add(Bytecode.OpStoreInt8ToArray);
                    break;

                case Mono.Cecil.Cil.Code.Stelem_I2:
                    Add(Bytecode.OpStoreInt16ToArray);
                    break;

                case Mono.Cecil.Cil.Code.Stelem_I4:
                    Add(Bytecode.OpStoreInt32ToArray);
                    break;

                case Mono.Cecil.Cil.Code.Stelem_I8:
                    Add(Bytecode.OpStoreInt64ToArray);
                    break;

                case Mono.Cecil.Cil.Code.Stelem_I:
                    Add(Bytecode.OpStoreNativeIntToArray);
                    break;

                case Mono.Cecil.Cil.Code.Stelem_R4:
                    Add(Bytecode.OpStoreFloatToArray);
                    break;

                case Mono.Cecil.Cil.Code.Stelem_R8:
                    Add(Bytecode.OpStoreDoubleToArray);
                    break;

                case Mono.Cecil.Cil.Code.Stelem_Any:
                case Mono.Cecil.Cil.Code.Stelem_Ref:
                    Add(Bytecode.OpStoreObjectToArray);
                    break;

                case Mono.Cecil.Cil.Code.Newobj:
                    Add(Bytecode.OpNewObject);
                    Immediate(Register(Directory.Get((MethodReference)instruction.Operand)));
                    break;

                case Mono.Cecil.Cil.Code.Initobj:
                    Add(Bytecode.OpInitializeObject);
                    Immediate(Register(Directory.Get((TypeReference)instruction.Operand)));
                    break;
                
                case Mono.Cecil.Cil.Code.Ldvirtftn:
                    Add(Bytecode.OpLoadVirtualMethodDescriptor);
                    Immediate(Register(Directory.Get((MethodReference)instruction.Operand)));
                    break;
                
                case Mono.Cecil.Cil.Code.Ldftn:
                    Add(Bytecode.OpLoadMethodDescriptor);
                    Immediate(Register(Directory.Get((MethodReference)instruction.Operand)));
                    break;
                
                case Mono.Cecil.Cil.Code.Constrained:
                {
                    // TODO CONSTRAINED PREFIX IS IGNORED! VERIFICATION IS NUKED!
                    break;
                }
                default:
                    Nuke();
                    break;
            }
        }

        BranchMachine.Fix();
        CompileHandlers();
    }
}