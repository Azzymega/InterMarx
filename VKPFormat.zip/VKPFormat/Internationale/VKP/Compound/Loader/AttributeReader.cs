﻿using Internationale.VKP.Image;
using Mono.Cecil;
using Attribute = Internationale.VKP.Image.Sections.Attribute;

namespace Internationale.VKP.Compound.Loader;

public class AttributeReader
{
    private Compound _compound;
    private AssemblyDefinition _assembly;

    private List<Attribute> _definitions;
    
    public AttributeReader(Compound compound, AssemblyDefinition assembly)
    {
        _compound = compound;
        _assembly = assembly;
        _definitions = new List<Attribute>();
    }

    public void Load()
    {
        LoadTypesAttributes();
        LoadMethodsAttributes();
        LoadFieldsAttributes();
        
        _compound.Attributes.AddRange(_definitions);
    }
    
    private void LoadTypesAttributes()
    {
        foreach (var type in _compound.TypeDefinitions)
        {
            foreach (var attribute in type.Definition.CustomAttributes)
            {
                Attribute newAttribute = new Attribute(attribute, type, _compound);
                
                if (!newAttribute.Declared.Characteristics.HasFlag(Characteristics.Import))
                {
                    _definitions.Add(newAttribute);
                }
            }
        }
    }

    private void LoadMethodsAttributes()
    {
        foreach (var methods in _compound.MethodDefinitions)
        {
            foreach (var attribute in methods.Definition.CustomAttributes)
            {
                Attribute newAttribute = new Attribute(attribute,methods,_compound);
                
                if (!newAttribute.Declared.Characteristics.HasFlag(Characteristics.Import))
                {
                    _definitions.Add(newAttribute);
                }
            }
        }
    }

    private void LoadFieldsAttributes()
    {
        foreach (var fields in _compound.FieldDefinitions)
        {
            foreach (var attribute in fields.Definition.CustomAttributes)
            {
                Attribute newAttribute = new Attribute(attribute,fields,_compound);
                
                if (!newAttribute.Declared.Characteristics.HasFlag(Characteristics.Import))
                {
                    _definitions.Add(newAttribute);
                }
            }
        }
    }
}