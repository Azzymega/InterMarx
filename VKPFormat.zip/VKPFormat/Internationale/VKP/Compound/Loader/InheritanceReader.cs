﻿using Mono.Cecil;

namespace Internationale.VKP.Compound.Loader;

public class InheritanceReader
{
    private Compound _compound;
    private AssemblyDefinition _assembly;

    public InheritanceReader(AssemblyDefinition assembly, Compound compound)
    {
        _assembly = assembly;
        _compound = compound;
    }

    public void Load()
    {
        foreach (var type in _compound.TypeDefinitions)
        {
            foreach (var implementation in type.Definition.Interfaces)
            {
                type.Interfaces.Add(_compound.Get(implementation.InterfaceType));
            }
        }
    }
}