﻿using Internationale.VKP.Image;
using Mono.Cecil;
using Mono.Cecil.Rocks;
using Type = Internationale.VKP.Image.Sections.Type;

namespace Internationale.VKP.Compound.Loader;

public class TypeReader
{
    private Compound _compound;
    private AssemblyDefinition _assembly;

    private List<Type> _definitions;

    public TypeReader(Compound compound, AssemblyDefinition assembly)
    {
        _compound = compound;
        _assembly = assembly;
        _definitions = new List<Type>();
    }

    public void Load()
    {
        LoadBaseTypeSystem();
        LoadTypes();
        _compound.TypeDefinitions.AddRange(_definitions);
        LoadSuper();
        ClearImport();
    }

    private void ClearImport()
    {
        List<Type> delete = new List<Type>();
        
        foreach (var type in _compound.TypeDefinitions)
        {
            foreach (var import in _compound.TypeImports)
            {
                if (type.FullName == import.FullName)
                {
                    delete.Add(import);
                }
            }
        }

        foreach (var type in delete)
        {
            _compound.TypeImports.Remove(type);
        }
    }
    
    private void LoadType(Type type)
    {
        foreach (var definition in _definitions)
        {
            if (definition.FullName == type.FullName)
            {
                throw new ArgumentException("Trying to add duplicate type!");
            }
        }

        if (type.Characteristics.HasFlag(Characteristics.Import))
        {
            _compound.TypeImports.Add(type);
        }
        else
        {
            _definitions.Add(type);            
        }
    }
    
    private void LoadSuper()
    {
        foreach (var type in _definitions)
        {
            if (type.FullName != "System.Object" && !type.Characteristics.HasFlag(Characteristics.Interface))
            {
                type.Base = _compound.Get(type.Definition.BaseType);
            }
        }

        foreach (var type in _compound.TypeGenerics)
        {
            if (type.FullName != "System.Object" && !type.Characteristics.HasFlag(Characteristics.Interface))
            {
                type.Base = _compound.Get(type.Definition.BaseType);
            }
        }
    }

    private void LoadBaseTypeSystem()
    {
        Type value = new Type(_assembly.MainModule.TypeSystem.Boolean);
        LoadType(value);
        
        value = new Type(_assembly.MainModule.TypeSystem.Int32);
        LoadType(value);
        
        value = new Type(_assembly.MainModule.TypeSystem.Char);
        LoadType(value);
        
        value = new Type(_assembly.MainModule.TypeSystem.Int64);
        LoadType(value);
        
        value = new Type(_assembly.MainModule.TypeSystem.Byte);
        LoadType(value);
        
        value = new Type(_assembly.MainModule.TypeSystem.Double);
        LoadType(value);
        
        value = new Type(_assembly.MainModule.TypeSystem.Int16);
        LoadType(value);
        
        value = new Type(_assembly.MainModule.TypeSystem.Object);
        LoadType(value);
        
        value = new Type(_assembly.MainModule.TypeSystem.Single);
        LoadType(value);
        
        value = new Type(_assembly.MainModule.TypeSystem.String);
        LoadType(value);
        
        value = new Type(_assembly.MainModule.TypeSystem.Void);
        LoadType(value);
        
        value = new Type(_assembly.MainModule.TypeSystem.IntPtr);
        LoadType(value);
        
        value = new Type(_assembly.MainModule.TypeSystem.SByte);
        LoadType(value);
        
        value = new Type(_assembly.MainModule.TypeSystem.UInt16);
        LoadType(value);
        
        value = new Type(_assembly.MainModule.TypeSystem.UInt32);
        LoadType(value);
        
        value = new Type(_assembly.MainModule.TypeSystem.UInt64);
        LoadType(value);
        
        value = new Type(_assembly.MainModule.TypeSystem.UIntPtr);
        LoadType(value);

        List<Type> arrays = new List<Type>();
        foreach (Type type in _compound.TypeImports)
        {
            _compound.Get(type.Reference.MakeArrayType());
        }
    }
    
    private void LoadTypes()
    {
        foreach (var type in _assembly.MainModule.Types)
        {
            if (type.FullName != "<Module>")
            {
                if (type.IsValueType && !type.IsPrimitive && !type.IsEnum && type.FullName != "System.Void")
                {
                    // TODO REPLACE!
                    //throw new ArgumentException("Struct is not supported now!");
                }
                Type newType = new Type(type);
                
                LoadType(newType);
                
                LoadNestedTypes(type);
            }
        }        
    }

    private void LoadNestedTypes(TypeDefinition definition)
    {
        foreach (var nestedType in definition.NestedTypes)
        {
            Type nested = new Type(nestedType);
            LoadType(nested);

            foreach (var type in nestedType.NestedTypes)
            {
                Type nestedNested = new Type(type);
                LoadType(nestedNested);
                
                LoadNestedTypes(type);
            }
        }
    }
}