﻿using Internationale.VKP.Image;
using Internationale.VKP.Image.Sections;
using Mono.Cecil;

namespace Internationale.VKP.Compound.Loader;

public class MethodReader
{
    private Compound _compound;
    private AssemblyDefinition _assembly;

    private List<Method> _definitions;
    private List<Method> _generics;
    
    public MethodReader(Compound compound, AssemblyDefinition assembly)
    {
        _compound = compound;
        _assembly = assembly;
        _definitions = new List<Method>();
        _generics = new List<Method>();
    }
    
    public void Load()
    {
        LoadMethods();
        _compound.MethodDefinitions.AddRange(_definitions);
    }

    private void LoadMethods()
    {
        foreach (var type in _compound.TypeDefinitions)
        {
            LoadTypeMethods(type.Definition);
        }
    }

    private void LoadTypeMethods(TypeDefinition definition)
    {
        foreach (var method in definition.Methods)
        {
            Method newMethod = new Method(method);

            newMethod.Return = _compound.Get(method.ReturnType);
            newMethod.Owner = _compound.Get(method.DeclaringType);

            if (!newMethod.Characteristics.HasFlag(Characteristics.Static))
            {
                newMethod.Parameters.Add(newMethod.Owner);
            }
            
            foreach (var parameter in method.Parameters)
            {
                newMethod.Parameters.Add(_compound.Get(parameter.ParameterType));
            }

            if (method.HasGenericParameters)
            {
                _generics.Add(newMethod);
            }
            else
            { 
                _definitions.Add(newMethod);
            }
        }
    }
}