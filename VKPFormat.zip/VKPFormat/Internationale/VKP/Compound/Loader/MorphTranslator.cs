﻿using System.Text;
using Internationale.VKP.Image;
using Internationale.VKP.Image.Sections;
using Mono.Cecil;
using Mono.Cecil.Rocks;
using Type = Internationale.VKP.Image.Sections.Type;

namespace Internationale.VKP.Compound.Loader;

public class MorphTranslator
{
    private Compound _compound;
    private AssemblyDefinition _assembly;
    
    public MorphTranslator(Compound compound, AssemblyDefinition assembly)
    {
        _compound = compound;
        _assembly = assembly;
    }
    
    public void Load()
    {
        GeneralizeTypes();

        // List<Method> remove = new List<Method>();
        // foreach (var method in _compound.MethodGenerics)
        // {
        //     if (method.Characteristics.HasFlag(Characteristics.Import))
        //     {
        //         remove.Add(method);
        //     }
        // }

        // foreach (var method in remove)
        // {
        //     _compound.MethodGenerics.Remove(method);
        // }
    }

    private Dictionary<string, Type> GenerateFixes(Type generic)
    {
        Dictionary<string, Type> types = new Dictionary<string, Type>();

        if (generic.Generic.GenericArguments.Count != generic.Base.Definition.GenericParameters.Count)
        {
            throw new ArgumentException($"Type {generic.FullName} mismatched generic arguments count! This is not supported!");
        }
        
        for (int i = 0; i < generic.Generic.GenericArguments.Count; i++)
        {
            types.Add(_compound.Get(generic.Base.Definition.GenericParameters[i]).FullName,_compound.Get(generic.Generic.GenericArguments[i]));
        }

        return types;
    }

    private Type Translate(Type source, Dictionary<string,Type> fix)
    {
        if (source.Characteristics.HasFlag(Characteristics.Template) || source.Characteristics.HasFlag(Characteristics.Aggregate))
        {
            if (source.Characteristics.HasFlag(Characteristics.Array))
            {
                Type fixUp = fix[_compound.Get(source.Reference.GetElementType()).FullName];

                if (fixUp.Definition != null)
                {
                    return _compound.Get(fixUp.Definition.MakeArrayType());
                }
                else
                {
                    return _compound.Get(fixUp.Reference.MakeArrayType());
                }
            }
            else
            {
                return fix[source.FullName];
            }
        }

        return source;
    }

    private string GenerateFixName(Type type, string fullName)
    {
        StringBuilder builder = new StringBuilder();

        builder.Append(fullName.Split("<")[0]);
        builder.Append("<");
        
        for (int i = 0; i < type.Generic.GenericArguments.Count; i++)
        {
            builder.Append(type.Generic.GenericArguments[i].FullName);
            if (i+1 < type.Generic.GenericArguments.Count)
            {
                builder.Append(',');
            }
        }

        builder.Append(">");
        builder.Append("::");
        builder.Append(fullName.Split("::")[1]);
        
        return builder.ToString();
    }
    
    private void GeneralizeTypes()
    {
        Dictionary<string, Field> fixedFields = new Dictionary<string, Field>();
        Dictionary<string, Method> fixedMethods = new Dictionary<string, Method>();
        List<Method> fixables = new List<Method>();
        
        foreach (var type in _compound.TypeGenerics)
        {
            if (type.Generic.GenericParameters.Count > 0)
            {
                throw new ArgumentException($"Type {type.FullName} has generic parameters! This is not supported!");
            }

            bool failed = false;
            foreach (var argument in type.Generic.GenericArguments)
            {
                if (argument.IsGenericParameter || argument.IsGenericInstance)
                {
                    failed = true;
                }
            }

            if (failed)
            {
                continue;
            }
            
            else
            {
                Dictionary<string, Type> fix = GenerateFixes(type);

                foreach (var field in type.Base.Fields)
                {
                    Field clone = (Field)field.Clone();
                    clone.SetOwner(type);

                    foreach (var generic in _compound.FieldGenerics)
                    {
                        if (generic.FullName == clone.FullName)
                        {
                            generic.Characteristics = clone.Characteristics;
                            clone = generic;
                            break;
                        }
                    }
                    
                    string oldName = GenerateFixName(type,clone.FullName);

                    if (field.Characteristics.HasFlag(Characteristics.Template))
                    {
                        clone.Declared = Translate(field.Declared,fix);
                    }

                    if (!clone.Declared.Characteristics.HasFlag(Characteristics.Template) || !clone.Declared.Characteristics.HasFlag(Characteristics.Aggregate))
                    {
                        if (clone.Characteristics.HasFlag(Characteristics.Template))
                        {
                            clone.Characteristics ^= Characteristics.Template;
                        }
                    }
                    
                    int index = type.IsFieldPresent(clone);
                    if (index != -1)
                    {
                        fixedFields.Add(oldName,type.Fields[index]);
                        
                        type.Fields[index].Declared = clone.Declared;
                        type.Fields[index].Characteristics = clone.Characteristics;
                        type.Fields[index].Definition = clone.Definition;
                        type.Fields[index].Reference = clone.Reference;
                    }
                    else
                    {
                        _compound.FieldGenerics.Add(clone);
                        type.Fields.Add(clone);
                        
                        fixedFields.Add(oldName,clone);
                    }
                }
                
                foreach (var method in type.Base.Methods)
                {
                    Method clone = (Method)method.Clone();
                    clone.SetOwner(type);

                    // foreach (var generic in _compound.MethodGenerics)
                    // {
                    //     if (generic.FullName == clone.FullName)
                    //     {
                    //         generic.Characteristics = clone.Characteristics;
                    //         generic.Executable = clone.Executable;
                    //         generic.Return = clone.Return;
                    //         generic.Parameters = clone.Parameters;
                    //         generic.Definition = clone.Definition;
                    //         generic.Reference = clone.Reference;
                    //         generic.SetOwner(type);
                    //         
                    //         //clone = generic;
                    //         break;
                    //     }
                    // }
                    
                    string oldName = GenerateFixName(type, clone.FullName);
                    
                    if (method.Characteristics.HasFlag(Characteristics.Template))
                    {
                        clone.Return = Translate(method.Return, fix);
                        if (!clone.Return.Characteristics.HasFlag(Characteristics.Template) || !clone.Return.Characteristics.HasFlag(Characteristics.Aggregate))
                        {
                            if (clone.Characteristics.HasFlag(Characteristics.Template))
                            {
                                clone.Characteristics ^= Characteristics.Template;
                            }
                        }

                        for (int i = 1; i < clone.Parameters.Count; i++)
                        {
                            clone.Parameters[i] = Translate(clone.Parameters[i], fix);
                            if (!clone.Parameters[i].Characteristics.HasFlag(Characteristics.Template) || !clone.Parameters[i].Characteristics.HasFlag(Characteristics.Aggregate))
                            {
                                if (clone.Characteristics.HasFlag(Characteristics.Template))
                                {
                                    clone.Characteristics ^= Characteristics.Template;
                                }
                            }
                        }

                        clone.Executable = (Executable)method.Executable.Clone();
                        clone.Executable.Owner = clone;
                        
                        if (type.IsMethodPresent(clone) != -1)
                        {
                            fixedMethods.Add(oldName,type.Methods[type.IsMethodPresent(clone)]);
                            
                            Method present = type.Methods[type.IsMethodPresent(clone)];
                            present.Characteristics = clone.Characteristics;
                            present.Executable = clone.Executable;
                            present.Executable.Owner = present;
                            present.Return = clone.Return;
                            clone = present;
                            fixables.Add(present);
                        }
                        else
                        {
                            type.Methods.Add(clone);
                            _compound.MethodGenerics.Add(clone);
                            fixedMethods.Add(oldName,clone);
                            fixables.Add(clone);
                        }
                        
                        for (int i = 0; i < clone.Executable.Pool.Count; i++)
                        {
                            if (clone.Executable.Pool[i] is Type poolType)
                            {
                                clone.Executable.Pool[i] = Translate(poolType, fix);
                            }
                        }     

                        for (int i = 0; i < clone.Executable.Variables.Count; i++)
                        {
                            clone.Executable.Variables[i] = Translate(clone.Executable.Variables[i], fix);
                        }
                        
                        _compound.MethodExecutables.Add(clone.Executable);

                        foreach (var handler in method.Executable.Handlers)
                        {
                            Handler newHandler = (Handler)handler.Clone();
                            newHandler.Owner = clone.Executable;

                            newHandler.Catch = Translate(newHandler.Catch, fix);
                            
                            _compound.ExecutableHandlers.Add(newHandler);
                        }
                    }
                }
            }
        }
        
        foreach (var clone in fixables)
        {
            for (int i = 0; i < clone.Executable.Pool.Count; i++)
            {
                if (clone.Executable.Pool[i] is Field fieldTarget)
                {
                    if (fieldTarget.Characteristics.HasFlag(Characteristics.Import) || fieldTarget.Characteristics.HasFlag(Characteristics.Template) || fieldTarget.Owner.Characteristics.HasFlag(Characteristics.Shapeshifter))
                    {
                        string fullName = "";
                        if (fieldTarget.Owner.Base.FullName != clone.Owner.Base.FullName)
                        {
                            fullName = GenerateFixName(fieldTarget.Owner, fieldTarget.FullName);
                        }
                        else
                        {
                            fullName = GenerateFixName(clone.Owner, fieldTarget.FullName);                            
                        }
                        clone.Executable.Pool[i] = fixedFields[fullName];
                    }
                }
                else if (clone.Executable.Pool[i] is Method methodTarget)
                {
                    if (methodTarget.Characteristics.HasFlag(Characteristics.Import) || methodTarget.Characteristics.HasFlag(Characteristics.Template) || methodTarget.Owner.Characteristics.HasFlag(Characteristics.Shapeshifter))
                    {
                        string name = "";
                        if (methodTarget.Owner.Base.FullName != clone.Owner.Base.FullName)
                        {
                            name = GenerateFixName(methodTarget.Owner, methodTarget.FullName);
                        }
                        else
                        {
                            name = GenerateFixName(clone.Owner, methodTarget.FullName);
                        }
                        clone.Executable.Pool[i] = fixedMethods[name];
                    }
                }
            }                    
        }
    }
}