﻿using System.Text;
using Internationale.VKP.Image;
using Internationale.VKP.Image.Sections;
using Mono.Cecil;
using Mono.Cecil.Rocks;
using Type = Internationale.VKP.Image.Sections.Type;

namespace Internationale.VKP.Compound.Loader;

class Map
{
    public Dictionary<string, Type> Types;
    public Dictionary<string, Field> Fields;
    public Dictionary<string, Method> Methods;

    public Map(Type generic, Compound compound)
    {
        Types = new Dictionary<string, Type>();
        Fields = new Dictionary<string, Field>();
        Methods = new Dictionary<string, Method>();
        
        for (int i = 0; i < generic.Generic.GenericArguments.Count; i++)
        {
            Types.Add(generic.Base.Definition.GenericParameters[i].FullName,generic.Arguments[i]);
            Types.TryAdd(Generalize(generic.Base.Definition.GenericParameters[i].FullName), generic.Arguments[i]);
            Types.Add(generic.Base.Definition.GenericParameters[i].MakeArrayType().FullName,compound.Get(generic.Generic.GenericArguments[i].MakeArrayType()));
        }
        
        Types.Add(generic.Base.FullName,generic);
        Types.TryAdd(Generalize(generic.Base.FullName), generic);
        Types.Add(generic.FullName,generic);
        Types.TryAdd(Generalize(generic.FullName), generic);
        
        foreach (var field in generic.Fields)
        {
            Fields.Add(generic.Base.GetGenericBase(field).FullName,field);
            Fields.TryAdd(Generalize(generic.Base.GetGenericBase(field).FullName), field);
            Fields.TryAdd(field.GenericBase.FullName, field);
            Fields.Add(field.FullName,field);
            Fields.TryAdd(Generalize(field.FullName), field);
        }
        
        foreach (var method in generic.Methods)
        {
            Methods.Add(generic.Base.GetGenericBase(method).FullName,method);
            Methods.TryAdd(Generalize(generic.Base.GetGenericBase(method).FullName),method);
            Methods.TryAdd(method.GenericBase.FullName, method);
            Methods.Add(method.FullName,method);
            Methods.TryAdd(Generalize(method.FullName),method);
        }

        foreach (var type in compound.TypeGenerics)
        {
            Types.TryAdd(type.FullName, type);
        }

        foreach (var method in compound.MethodGenerics)
        {
            Methods.TryAdd(method.FullName, method);
        }

        foreach (var field in compound.FieldGenerics)
        {
            Fields.TryAdd(field.FullName, field);
        }
    }

    private string Generalize(string fullName)
    {
        if (!fullName.Contains('<') || !fullName.Contains('>'))
        {
            return fullName;
        }
        
        StringBuilder builder = new StringBuilder();

        string typeName = fullName.Split(" ")[0];
        foreach (var type in Types)
        {
            if (type.Value.FullName == typeName)
            {
                typeName = type.Key;
            }
        }

        string[] parameters = fullName.Split("<")[1].Split(">")[0].Split(",");
        foreach (var type in Types)
        {
            for (int i = 0; i < parameters.Length; i++)
            {
                if (fullName.Contains('<'))
                {
                    if (type.Value.FullName == parameters[i])
                    {
                        parameters[i] = type.Key;
                    }                        
                }
            }
        }

        if (parameters.Length > 0)
        {
            if (fullName.Contains(' '))
            {
                builder.Append(typeName);
                builder.Append(" ");
                builder.Append(fullName.Split(" ")[1].Split("<")[0]);
                builder.Append('<');
                for (int i = 0; i < parameters.Length; i++)
                {
                    builder.Append(parameters[i]);
                    if (i+1<parameters.Length)
                    {
                        builder.Append(',');
                    }
                }
                builder.Append('>');
                builder.Append(fullName.Split(">")[1]);
            }
            else
            {
                builder.Append(fullName.Split("<")[0]);
                builder.Append('<');
                for (int i = 0; i < parameters.Length; i++)
                {
                    builder.Append(parameters[i]);
                    if (i+1<parameters.Length)
                    {
                        builder.Append(',');
                    }
                }
                builder.Append('>');
                builder.Append(fullName.Split(">")[1]);
            }
        }

        return builder.ToString();
    }
}

public class GeneralizeTranslator
{
    private Compound _compound;
    private AssemblyDefinition _assembly;

    public GeneralizeTranslator(Compound compound, AssemblyDefinition assembly)
    {
        _compound = compound;
        _assembly = assembly;
    }

    private void CloneBase(Type type)
    {
        Type generic = type.Base;
        foreach (var field in generic.Fields)
        {
            Field target = type.GetGenericBase(field);

            if (target == null)
            {
                target = (Field?)field.Clone();
                target.GenericBase = field;
                target.SetOwner(type);
                type.Fields.Add(target);
                _compound.FieldGenerics.Add(target);
            }
            else
            {
                target.GenericBase = field;
            }
        }

        foreach (var method in generic.Methods)
        {
            Method target = type.GetGenericBase(method);
            
            if (target == null)
            {
                target = (Method?)method.Clone();
                target.GenericBase = method;
                target.SetOwner(type);
                type.Methods.Add(target);
                _compound.MethodGenerics.Add(target);    
            }
            else
            {
                target.GenericBase = method;
            }
            
            if (method.Executable != null)
            {
                target.Executable = (Executable)method.Executable.Clone();
                target.Executable.Owner = target;
                    
                _compound.MethodExecutables.Add(target.Executable);
            }
        }
    }

    private bool Swap(Type type)
    {
        if (type.Characteristics.HasFlag(Characteristics.Template) || type.Characteristics.HasFlag(Characteristics.Aggregate))
        {
            return true;
        }

        return false;
    }

    private bool Swap(Field field)
    {
        if (field.Characteristics.HasFlag(Characteristics.Template))
        {
            return true;
        }

        return false;
    }
    
    private bool Swap(Method method)
    {
        if (method.Characteristics.HasFlag(Characteristics.Template))
        {
            return true;
        }

        return false;
    }


    private void Translate(Type type)
    {
        Map map = new Map(type,_compound);

        foreach (var field in type.Fields)
        {
            if (Swap(field.Declared))
            {
                field.Declared = map.Types[field.Declared.FullName];
            }
        }

        foreach (var method in type.Methods)
        {
            if (Swap(method.Return))
            {
                method.Return = map.Types[method.Return.FullName];
            }

            for (int i = 0; i < method.Parameters.Count; i++)
            {
                if (Swap(method.Parameters[i]))
                {
                    method.Parameters[i] = map.Types[method.Parameters[i].FullName];
                }
            }

            if (method.Executable != null)
            {
                Executable target = method.Executable;
                
                for (int i = 0; i < target.Variables.Count; i++)
                {
                    if (Swap(target.Variables[i]))
                    {
                        target.Variables[i] = map.Types[target.Variables[i].FullName];
                    }
                }

                for (int i = 0; i < target.Pool.Count; i++)
                {
                    if (target.Pool[i] is Type poolType)
                    {
                        if (Swap(poolType))
                        {
                            target.Pool[i] = map.Types[poolType.FullName];
                        }
                    }
                    else if (target.Pool[i] is Field poolField)
                    {
                        if (Swap(poolField))
                        {
                            target.Pool[i] = map.Fields[poolField.FullName];
                        }
                    }
                    else if (target.Pool[i] is Method poolMethod)
                    {
                        if (Swap(poolMethod))
                        {
                            target.Pool[i] = map.Methods[poolMethod.FullName];
                        }
                    }
                }
            }
        }
    }

    public void Load()
    {
        foreach (var type in _compound.TypeGenerics)
        {
            CloneBase(type);
        }

        foreach (var type in _compound.TypeGenerics)
        {
            Translate(type);
        }
    }
}