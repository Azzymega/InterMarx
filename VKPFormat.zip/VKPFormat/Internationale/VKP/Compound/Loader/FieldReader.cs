﻿using Internationale.VKP.Image.Sections;
using Mono.Cecil;

namespace Internationale.VKP.Compound.Loader;

public class FieldReader
{
    private Compound _compound;
    private AssemblyDefinition _assembly;

    private List<Field> _definitions;
    private List<Field> _generics;

    public FieldReader(Compound compound, AssemblyDefinition assembly)
    {
        _compound = compound;
        _assembly = assembly;
        _definitions = new List<Field>();
        _generics = new List<Field>();
    }

    public void Load()
    {
        LoadFields();
        _compound.FieldDefinitions.AddRange(_definitions);
        _compound.FieldGenerics.AddRange(_generics);
    }

    private void LoadFields()
    {
        foreach (var type in _compound.TypeDefinitions)
        {
            LoadTypeFields(type.Definition);
        }
    }
    
    private void LoadTypeFields(TypeDefinition definition)
    {
        foreach (var field in definition.Fields)
        {
            Field target = new Field(field);
            target.Owner = _compound.Get(field.DeclaringType);
            target.Declared = _compound.Get(field.FieldType);

            if (field.ContainsGenericParameter)
            {
                _generics.Add(target);
            }
            else
            {
                _definitions.Add(target);
            }
        }
    }
}