﻿using Internationale.VKP.Image;
using Internationale.VKP.Image.Sections;
using Mono.Cecil;

namespace Internationale.VKP.Compound.Loader;

public class ArgumentReader
{
    private Compound _compound;
    private AssemblyDefinition _assembly;

    private List<Argument> _definitions;
    
    public ArgumentReader(Compound compound, AssemblyDefinition assembly)
    {
        _compound = compound;
        _assembly = assembly;
        _definitions = new List<Argument>();
    }

    public void Load()
    {
        LoadArguments();

        _compound.Arguments.AddRange(_definitions);
    }

    private void LoadArguments()
    {
        foreach (var attribute in _compound.Attributes)
        {
            foreach (var argument in attribute.CustomAttribute.ConstructorArguments)
            {
                Argument newArgument = new Argument(argument, attribute, _compound);
                
                if (!newArgument.Declared.Characteristics.HasFlag(Characteristics.Import))
                {
                    _definitions.Add(newArgument);
                }
            }
        }
    }
}