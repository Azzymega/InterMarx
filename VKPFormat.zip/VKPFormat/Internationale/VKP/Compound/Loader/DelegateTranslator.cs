﻿using Internationale.VKP.Image;
using Internationale.VKP.Image.Code;
using Internationale.VKP.Image.Sections;
using Mono.Cecil;
using Mono.Cecil.Rocks;
using Type = Internationale.VKP.Image.Sections.Type;

namespace Internationale.VKP.Compound.Loader;

public class DelegateTranslator
{
    public AssemblyDefinition Definition { get; set; }
    public Compound Compound { get; set; }

    public DelegateTranslator(AssemblyDefinition definition, Compound compound)
    {
        Definition = definition;
        Compound = compound;
    }

    public void Load()
    {
        foreach (var type in Compound.TypeDefinitions)
        {
            if (type.Base != null && type.Base.FullName == "System.MulticastDelegate")
            {
                foreach (var method in type.Methods)
                {
                    if (method.Definition.IsConstructor)
                    {
                        Executable executable = new Executable();
                        byte[] binaryCode = new byte[]
                        {
                            (byte)Bytecode.OpLoadArgument, 0, 0, 0, 0, (byte)Bytecode.OpLoadArgument, 1, 0, 0, 0,
                            (byte)Bytecode.OpLoadArgument, 2, 0, 0, 0, (byte)Bytecode.OpCall, 0, 0, 0, 0,
                            (byte)Bytecode.OpNoOperation, (byte)Bytecode.OpNoOperation, (byte)Bytecode.OpReturn
                        };
                        
                        executable.Owner = method;
                        executable.Image = new List<byte>(binaryCode);
                        executable.Types.Add(SectionType.Method);

                        Type voidType = Compound.Get("System.Void");
                        
                        TypeReference voidTypeReference = null;
                        TypeReference mcastTypeReference = null;

                        if (type.Base.Reference == null)
                        {
                            mcastTypeReference = type.Base.Definition;
                        }
                        else
                        {
                            mcastTypeReference = type.Base.Reference;
                        }
                        
                        if (voidType.Reference == null)
                        {
                            voidTypeReference = voidType.Definition;
                        }
                        else
                        {
                            voidTypeReference = voidType.Reference;
                        }
                        
                        MethodReference reference = new MethodReference(
                            ".ctor",
                            voidTypeReference,mcastTypeReference);
                        
                        reference.Parameters.Add(new ParameterDefinition(Definition.MainModule.TypeSystem.Object));
                        reference.Parameters.Add(new ParameterDefinition(Definition.MainModule.TypeSystem.IntPtr));
                        
                        executable.Pool.Add(Compound.Get(reference));
                        
                        Compound.MethodExecutables.Add(executable);

                        method.Characteristics &= (~Characteristics.Extern);
                    }
                }
            }
        }
    }
}