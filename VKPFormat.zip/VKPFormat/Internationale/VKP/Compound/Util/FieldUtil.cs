﻿using Mono.Cecil;

namespace Internationale.VKP.Compound.Util;

public static class FieldUtil
{
    public static bool IsImport(FieldReference reference)
    {
        if (reference.IsDefinition)
        {
            return false;
        }

        return true;
    } 
    
    public static bool IsGeneric(FieldReference reference)
    {
        if (reference.ContainsGenericParameter)
        {
            return true;
        }

        return false;
    }
}