﻿using Mono.Cecil;

namespace Internationale.VKP.Compound.Util;

public static class MethodUtil
{
    public static bool IsImport(MethodReference reference)
    {
        if (reference.IsDefinition)
        {
            return false;
        }

        return true;
    }

    public static bool IsGeneric(MethodReference reference)
    {
        if (reference.IsGenericInstance || reference.ContainsGenericParameter || reference.HasGenericParameters || reference.DeclaringType is GenericInstanceType)
        {
            return true;
        }

        return false;
    }

    public static bool IsDelegateCall(MethodReference reference)
    {
        if (reference.DeclaringType.Resolve().BaseType.FullName == "System.MulticastDelegate")
        {
            return true;
        }

        return false;
    }
}