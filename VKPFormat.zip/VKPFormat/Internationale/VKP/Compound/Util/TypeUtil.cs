﻿using Mono.Cecil;

namespace Internationale.VKP.Compound.Util;

public static class TypeUtil
{
    public static bool IsSynthetic(TypeReference reference)
    {
        if (reference.IsArray || reference.IsPointer || reference.IsByReference || reference.IsGenericParameter || reference.IsGenericInstance)
        {
            return true;
        }

        return false;
    }

    public static bool IsImport(TypeReference reference)
    {
        if (!reference.IsDefinition && !IsSynthetic(reference))
        {
            return true;
        }

        return false;
    }
}