﻿using Internationale.VKP.Compound.Loader;
using Internationale.VKP.Compound.Util;
using Internationale.VKP.Image;
using Internationale.VKP.Image.Sections;
using Mono.Cecil;
using Attribute = Internationale.VKP.Image.Sections.Attribute;
using Type = Internationale.VKP.Image.Sections.Type;

namespace Internationale.VKP.Compound;

public class Compound
{
    public Strings Table { get; set; }

    public List<Type> TypeDefinitions { get; set; }
    public List<Type> TypeImports { get; set; }
    
    public List<Type> Arrays { get; set; }
    public List<Type> Pointers { get; set; }
    public List<Type> References { get; set; }
    
    public List<Type> TypeGenerics { get; set; }
    public List<Field> FieldGenerics { get; set; }
    public List<Method> MethodGenerics { get; set; }
    public List<Type> TypeAggregates { get; set; }

    public List<Field> FieldDefinitions { get; set; }
    public List<Field> FieldImports { get; set; }

    public List<Method> MethodDefinitions { get; set; }
    public List<Method> MethodImports { get; set; }

    public List<Executable> MethodExecutables { get; set; }
    public List<Handler> ExecutableHandlers { get; set; }

    public List<Attribute> Attributes { get; set; }
    public List<Argument> Arguments { get; set; }

    public Compound()
    {
        Table = new Strings();
        TypeDefinitions = new List<Type>();
        TypeImports = new List<Type>();
        Arrays = new List<Type>();
        Pointers = new List<Type>();
        References = new List<Type>();
        FieldDefinitions = new List<Field>();
        FieldImports = new List<Field>();
        MethodDefinitions = new List<Method>();
        MethodImports = new List<Method>();
        MethodExecutables = new List<Executable>();
        ExecutableHandlers = new List<Handler>();
        Attributes = new List<Attribute>();
        Arguments = new List<Argument>();
        TypeGenerics = new List<Type>();
        TypeAggregates = new List<Type>();
        FieldGenerics = new List<Field>();
        MethodGenerics = new List<Method>();
    }

    public void Register(Handler handler)
    {
        ExecutableHandlers.Add(handler);
    }
    
    public void Register(Executable executable)
    {
        MethodExecutables.Add(executable);
    }
    
    public void Load(AssemblyDefinition definition)
    {
        TypeReader reader = new TypeReader(this,definition);
        reader.Load();

        FieldReader fieldReader = new FieldReader(this, definition);
        fieldReader.Load();

        MethodReader methodReader = new MethodReader(this, definition);
        methodReader.Load();

        AttributeReader attributeReader = new AttributeReader(this, definition);
        attributeReader.Load();

        ArgumentReader argumentReader = new ArgumentReader(this, definition);
        argumentReader.Load();

        foreach (var method in MethodDefinitions)
        {
            if (method.Definition.HasBody)
            {
                ILTranslator translator = new ILTranslator(this,method.Definition,method);
                translator.Compile();                
            }
        }

        GeneralizeTranslator generalizeTranslator = new GeneralizeTranslator(this, definition);
        generalizeTranslator.Load();

        InheritanceReader inheritanceReader = new InheritanceReader(definition,this);
        inheritanceReader.Load();

        DelegateTranslator delegateTranslator = new DelegateTranslator(definition,this);
        delegateTranslator.Load();
    }

    public Type Get(string fullName)
    {
        foreach (var type in TypeDefinitions)
        {
            if (type.FullName == fullName)
            {
                return type;
            }
        }

        foreach (var type in TypeGenerics)
        {
            if (type.FullName == fullName)
            {
                return type;
            }
        }

        foreach (var type in TypeImports)
        {
            if (type.FullName == fullName)
            {
                return type;
            }
        }
        
        throw new ArgumentException($"Type {fullName} is not found!");
    }
    
    public Type Get(TypeReference reference)
    {
        foreach (var type in TypeDefinitions)
        {
            if (type.FullName == reference.FullName)
            {
                return type;
            }
        }

        foreach (var type in TypeGenerics)
        {
            if (type.FullName == reference.FullName)
            {
                return type;
            }
        }

        foreach (var type in TypeImports)
        {
            if (type.FullName == reference.FullName)
            {
                return type;
            }
        }
        
        if (TypeUtil.IsSynthetic(reference))
        {
            return Synthetic(reference);
        }

        if (TypeUtil.IsImport(reference))
        {
            return Import(reference);
        }

        throw new ArgumentException($"Type {reference.FullName} is not found!");
    }

    private Type Synthetic(TypeReference reference)
    {
        if (reference.IsArray)
        {
            foreach (var type in Arrays)
            {
                if (type.FullName == reference.FullName)
                {
                    return type;
                }
            }

            Type newArray = new Type(reference);
            Arrays.Add(newArray);
            return newArray;
        }

        if (reference.IsPointer)
        {
            foreach (var type in Pointers)
            {
                if (type.FullName == reference.FullName)
                {
                    return type;
                }
            }
            
            Type newArray = new Type(reference);
            Pointers.Add(newArray);
            return newArray;
        }
        if (reference.IsByReference)
        {
            foreach (var type in References)
            {
                if (type.FullName == reference.FullName)
                {
                    return type;
                }
            }
            
            Type newArray = new Type(reference);
            References.Add(newArray);
            return newArray;
        }

        if (reference.IsGenericInstance)
        {
            foreach (var type in TypeGenerics)
            {
                if (type.FullName == reference.FullName)
                {
                    return type;
                }
            }

            Type newGeneric = new Type(reference);
            GenericInstanceType genericInstanceType = (GenericInstanceType)reference;
            newGeneric.Base = Get(genericInstanceType.ElementType);

            foreach (var argument in genericInstanceType.GenericArguments)
            {
                newGeneric.Arguments.Add(Get(argument));
            }
            
            TypeGenerics.Add(newGeneric);
            return newGeneric;
        }

        if (reference.IsGenericParameter)
        {
            foreach (var type in TypeAggregates)
            {
                if (type.FullName == reference.FullName)
                {
                    return type;
                }
            }

            Type newGeneric = new Type(reference);
            TypeAggregates.Add(newGeneric);
            return newGeneric;
        }

        throw new ArgumentException($"Synthetic type {reference.FullName} is not found!");
    }

    private Type Import(TypeReference reference)
    {
        foreach (var type in TypeImports)
        {
            if (type.FullName == reference.FullName)
            {
                return type;
            }
        }

        Type target = new Type(reference);
        TypeImports.Add(target);
        return target;
    }
    
    private Field Import(FieldReference reference)
    {
        foreach (var field in FieldImports)
        {
            if (field.FullName == reference.FullName)
            {
                return field;
            }
        }

        Field target = new Field(reference);

        target.Owner = Get(reference.DeclaringType);
        target.Declared = Get(reference.FieldType);
        
        FieldImports.Add(target);
        return target;
    }
    
    private Field Synthetic(FieldReference reference)
    {
        if (reference.ContainsGenericParameter)
        {
            Field newGeneric = new Field(reference);
            newGeneric.Declared = Get(reference.FieldType);
            newGeneric.Owner = Get(reference.DeclaringType);
            FieldGenerics.Add(newGeneric);
            
            if (newGeneric.Characteristics.HasFlag(Characteristics.Import))
            {
                newGeneric.Characteristics ^= Characteristics.Import;
            }

            if (!newGeneric.Characteristics.HasFlag(Characteristics.Template))
            {
                newGeneric.Characteristics |= Characteristics.Template; 
            }
            
            return newGeneric;
        }

        throw new ArgumentException($"Synthetic field {reference.FullName} is not found!");
    }
    
    private Method Synthetic(MethodReference reference)
    {
        if (MethodUtil.IsGeneric(reference))
        {
            Method target = new Method(reference);
        
            target.Return = Get(reference.ReturnType);
            target.Owner = Get(reference.DeclaringType);

            if (!target.Characteristics.HasFlag(Characteristics.Static))
            {
                target.Parameters.Add(target.Owner);
            }
            
            foreach (var parameter in reference.Parameters)
            {
                target.Parameters.Add(Get(parameter.ParameterType));
            }
            
            MethodGenerics.Add(target);

            if (target.Characteristics.HasFlag(Characteristics.Import))
            {
                target.Characteristics ^= Characteristics.Import;
            }

            if (!target.Characteristics.HasFlag(Characteristics.Template))
            {
                target.Characteristics |= Characteristics.Template; 
            }
            
            return target;
        }

        throw new ArgumentException($"Synthetic method {reference.FullName} is not found!");
    }
    
    private Method Import(MethodReference reference)
    {
        foreach (var method in MethodImports)
        {
            if (method.FullName == reference.FullName)
            {
                return method;
            }
        }

        Method target = new Method(reference);
        
        target.Return = Get(reference.ReturnType);
        target.Owner = Get(reference.DeclaringType);

        if (!target.Characteristics.HasFlag(Characteristics.Static))
        {
            target.Parameters.Add(target.Owner);
        }
        
        foreach (var parameter in reference.Parameters)
        {
            target.Parameters.Add(Get(parameter.ParameterType));
        }
        
        MethodImports.Add(target);
        return target;
    }

    public Field Get(FieldReference reference)
    {
        foreach (var field in FieldDefinitions)
        {
            if (field.FullName == reference.FullName)
            {
                return field;
            }
        }

        foreach (var field in FieldImports)
        {
            if (field.FullName == reference.FullName)
            {
                return field;
            }
        }
        
        foreach (var field in FieldGenerics)
        {
            if (field.FullName == reference.FullName)
            {
                return field;
            }
        }

        if (FieldUtil.IsGeneric(reference))
        {
            return Synthetic(reference);
        }
        else if (FieldUtil.IsImport(reference))
        {
            return Import(reference);
        }
        
        throw new ArgumentException($"Field {reference.FullName} is not found!");
    }

    public Method Get(MethodReference reference)
    {
        foreach (var method in MethodDefinitions)
        {
            if (method.FullName == reference.FullName)
            {
                return method;
            }
        }

        foreach (var method in MethodImports)
        {
            if (method.FullName == reference.FullName)
            {
                return method;
            }
        }

        foreach (var method in MethodGenerics)
        {
            if (method.FullName == reference.FullName)
            {
                return method;
            }
        }

        if (MethodUtil.IsGeneric(reference))
        {
            return Synthetic(reference);
        }
        else if (MethodUtil.IsImport(reference))
        {
            return Import(reference);
        }
        
        throw new ArgumentException($"Method {reference.FullName} is not found!");
    }
}