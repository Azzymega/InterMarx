﻿namespace Internationale.VKP.May;

public class Register
{
    public int Index;

    public Register(int index)
    {
        Index = index;
    }

    public override string ToString()
    {
        return 'R' + Index.ToString();
    }

    public override bool Equals(object? obj)
    {
        if (obj is Register register)
        {
            return register.Index == this.Index;
        }

        return false;
    }
}