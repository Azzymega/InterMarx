﻿using Internationale.VKP.Image.Code;

namespace Internationale.VKP.May;

public class Optimizer
{
    private readonly RegisterTranslator _compiler;
    
    public Optimizer(RegisterTranslator compiler)
    {
        _compiler = compiler;
    }

    public void OptimizeMoves()
    {
        List<Instruction> targetsForRemoval = new List<Instruction>();
        
        for (int i = 0; i < _compiler.Instructions.Count; i++)
        {
            Instruction instruction = _compiler.Instructions[i];
            if (i + 1 < _compiler.Instructions.Count)
            {
                Instruction next = _compiler.Instructions[i + 1];

                if (instruction.Bytecode == Bytecode.OpMove && next.Bytecode == Bytecode.OpMove)
                {
                    if (instruction.Registers[0].Equals(next.Result) && next.Registers[0].Equals(instruction.Result))
                    {
                        targetsForRemoval.Add(next);
                    }
                }
            }
        }
    }
}