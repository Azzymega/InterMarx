﻿using System.Text;
using Internationale.VKP.Image.Code;

namespace Internationale.VKP.May;

public class Instruction
{
    public long InitialOffset;
    public Bytecode Bytecode;
    public Register[] Registers;
    public Register Result;
    public object Immediate;
    
    public Instruction(Bytecode bytecode, long initialOffset)
    {
        Bytecode = bytecode;
        InitialOffset = initialOffset;
        Registers = new Register[0];
        Result = null;
    }
    
    public Instruction(Bytecode bytecode, long initialOffset, params Register[] registers)
    {
        Bytecode = bytecode;
        InitialOffset = initialOffset;
        Registers = registers;
    } 

    public Instruction(Bytecode bytecode, Register result, long initialOffset, params Register[] registers)
    {
        Bytecode = bytecode;
        Result = result;
        InitialOffset = initialOffset;
        Registers = registers;
    }

    public override string ToString()
    {
        StringBuilder builder = new StringBuilder($"{Bytecode}(");

        for (int i = 0; i < Registers.Length; i++)
        {
            builder.Append(Registers[i]);

            if (i + 1 < Registers.Length)
            {
                builder.Append(',');
            }
        }
        
        builder.Append(')');
        
        if (Result != null)
        {
            builder.Append($" = {Result}");
        }
        
        if (Immediate != null)
        {
            builder.Append($" | with immediate {Immediate}");
        }
        
        return builder.ToString();
    }
}