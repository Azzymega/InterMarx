﻿namespace Internationale.VKP.May;

public class StackMachine
{
    public List<Register> Registers;
    public Stack<Register> Stack;
    public int OffsetIndex;

    public StackMachine(int locals)
    {
        Stack = new Stack<Register>();
        Registers = new List<Register>();
        OffsetIndex = locals;
    }

    public Register Push()
    {
        Stack.Push(new Register(OffsetIndex+Stack.Count));
        return Stack.Peek();
    }

    public Register Deallocate()
    {
        return Stack.Pop();
    }

    public Register Get(int index)
    {
        return new Register(index);
    }
}