﻿using Internationale.VKP.Image.Code;
using Internationale.VKP.Image.Sections;
using Type = Internationale.VKP.Image.Sections.Type;

namespace Internationale.VKP.May;

public class RegisterTranslator
{
    public Method Method;
    public List<Instruction> Instructions;
    public StackMachine StackMachine;
    public BinaryReader CodeReader;
    public long Offset;
    
    public RegisterTranslator()
    {
        Instructions = new List<Instruction>();
    }

    public void Emit(Bytecode bytecode)
    {
        Instructions.Add(new Instruction(bytecode,Offset));
    }
    
    public void Emit(Bytecode bytecode, int popCount, bool push)
    {
        List<Register> pops = new List<Register>();
        for (int i = 0; i < popCount; i++)
        {
            pops.Add(StackMachine.Deallocate());
        }

        if (push)
        {
            Instructions.Add(new Instruction(bytecode,StackMachine.Push(),Offset,pops.ToArray()));            
        }
        else
        {
            Instructions.Add(new Instruction(bytecode,Offset,pops.ToArray()));     
        }

    }

    public void Emit(Bytecode bytecode, int popCount, bool push, object immediate)
    {
        List<Register> pops = new List<Register>();
        for (int i = 0; i < popCount; i++)
        {
            pops.Add(StackMachine.Deallocate());
        }

        if (push)
        {
            Instruction instruction = new Instruction(bytecode, StackMachine.Push(),Offset,pops.ToArray());
            instruction.Immediate = immediate;
            Instructions.Add(instruction);            
        }
        else
        {
            Instruction instruction = new Instruction(bytecode,Offset,pops.ToArray());
            instruction.Immediate = immediate;
            Instructions.Add(instruction);     
        }

    }

    public Instruction Locate(int offset)
    {
        foreach (var instruction in Instructions)
        {
            if (instruction.InitialOffset == offset)
            {
                return instruction;
            }
        }

        throw new ArgumentException("Failed to find instruciton at this offset");
    }
    
    public void Emit(Bytecode bytecode, Register target, params Register[] source)
    {
        Instructions.Add(new Instruction(bytecode,target,Offset,source));
    }
    
    public void Compile(Method method, Compound.Compound compound)
    {
        Method = method;
        StackMachine = new StackMachine(method.Executable.Variables.Count);
        Bytecode previousBytecode = Bytecode.OpBreakpoint;
        CodeReader = new BinaryReader(new MemoryStream(method.Executable.Image.ToArray()));
        while (CodeReader.BaseStream.Position < method.Executable.Image.Count)
        {
            Offset = CodeReader.BaseStream.Position;
            Bytecode bytecode = (Bytecode)CodeReader.ReadByte();

            switch (bytecode)
            {
                case Bytecode.OpBreakpoint:
                {
                    Emit(bytecode);
                    break;
                }
                case Bytecode.OpNoOperation:
                {
                    Emit(bytecode);
                    break;
                }
                case Bytecode.OpDup:
                {
                    Register target = StackMachine.Stack.Peek();
                    Emit(Bytecode.OpMove,StackMachine.Push(),target);
                    break;
                }
                case Bytecode.OpPop:
                {
                    StackMachine.Deallocate();
                    break;
                }
                case Bytecode.OpAdd:
                case Bytecode.OpDiv:
                case Bytecode.OpMu:
                case Bytecode.OpSub:
                case Bytecode.OpXor:
                case Bytecode.OpShiftRight:
                case Bytecode.OpOr:
                case Bytecode.OpShiftLeft:
                case Bytecode.OpAnd:
                case Bytecode.OpRem:
                {
                    Emit(bytecode,2,true);
                    break;
                }
                case Bytecode.OpNot:
                case Bytecode.OpNeg:
                {
                    Emit(bytecode,1,true);
                    break;
                }
                case Bytecode.OpConvertFloat:
                case Bytecode.OpConvertI64:
                case Bytecode.OpConvertI32:
                case Bytecode.OpConvertI16:
                case Bytecode.OpConvertI8:
                case Bytecode.OpConvertIntPtr:
                case Bytecode.OpConvertDouble:
                {
                    Emit(bytecode,1,true);
                    break;
                }
                case Bytecode.OpStoreStaticField:
                {
                    int index = CodeReader.ReadInt32();
                    Field field = (Field)method.Executable.Pool[index];
                    Emit(bytecode,1,false,field);
                    break;
                }
                case Bytecode.OpLoadValueFromPointer:
                {
                    int index = CodeReader.ReadInt32();
                    Type type = (Type)method.Executable.Pool[index];
                    Emit(bytecode,1,true,type);
                    break;
                }
                case Bytecode.OpLoadStaticField:
                {
                    int index = CodeReader.ReadInt32();
                    Field field = (Field)method.Executable.Pool[index];
                    Emit(bytecode,0,true,field);
                    break;
                }
                case Bytecode.OpLoadValueField:
                case Bytecode.OpLoadValueFieldAddress:
                {
                    int index = CodeReader.ReadInt32();
                    Field field = (Field)method.Executable.Pool[index];
                    Emit(bytecode,1,true,field);
                    break;
                }
                case Bytecode.OpLoadArgumentAddress:
                case Bytecode.OpLoadLocalVariableAddress:
                {
                    Emit(bytecode,0,true,CodeReader.ReadInt32());
                    break;
                }
                case Bytecode.OpStoreValueToPointer:
                {
                    int index = CodeReader.ReadInt32();
                    Type type = (Type)method.Executable.Pool[index];
                    Emit(bytecode,2,false,type);
                    break;
                }
                case Bytecode.OpStoreValueField:
                {
                    int index = CodeReader.ReadInt32();
                    Field field = (Field)method.Executable.Pool[index];
                    Emit(bytecode,2,false,field);
                    break;
                }
                case Bytecode.OpLoadAddressOfArrayElement:
                {
                    int index = CodeReader.ReadInt32();
                    Type arrayType = (Type)method.Executable.Pool[index];
                    Emit(bytecode,2,true,arrayType);
                    break;
                }
                case Bytecode.OpLoadVirtualMethodDescriptor:
                {
                    int index = CodeReader.ReadInt32();
                    Method value = (Method)method.Executable.Pool[index];
                    Emit(bytecode,1,true,value);
                    break;
                }
                case Bytecode.OpStoreLocal:
                {
                    int storeIndex = CodeReader.ReadInt32();
                    Register target = StackMachine.Get(storeIndex);
                    Emit(Bytecode.OpMove,target,StackMachine.Deallocate());
                    break;
                }
                case Bytecode.OpStoreArgument:
                {
                    Emit(bytecode,1,false);
                    break;
                }
                case Bytecode.OpLoadNull:
                {
                    Emit(bytecode,0,true);
                    break;
                }
                case Bytecode.OpLoadLocal:
                {
                    int localIndex = CodeReader.ReadInt32();
                    Register target = StackMachine.Get(localIndex);
                    Emit(Bytecode.OpMove,StackMachine.Push(),target);
                    break;
                }
                case Bytecode.OpLoadArgument:
                {
                    Emit(bytecode,0,true,CodeReader.ReadInt32());
                    break;
                }
                case Bytecode.OpLoadString:
                {
                    int index = CodeReader.ReadInt32();
                    string value = (string)method.Executable.StringsTable[index];
                    Emit(bytecode,0,true,value);
                    break;
                }
                case Bytecode.OpLoadMethodDescriptor:
                {
                    int index = CodeReader.ReadInt32();
                    Method value = (Method)method.Executable.Pool[index];
                    Emit(bytecode,0,true,value);
                    break;
                }
                case Bytecode.OpNewArray:
                {
                    CodeReader.ReadInt32();
                    int index = CodeReader.ReadInt32();
                    Type value = (Type)method.Executable.Pool[index];
                    Emit(bytecode,1,true,value);
                    break;
                }
                case Bytecode.OpInitializeObject:
                {
                    int index = CodeReader.ReadInt32();
                    Type value = (Type)method.Executable.Pool[index];
                    Emit(bytecode,1,false,value);
                    break;
                }
                case Bytecode.OpNewObject:
                {
                    int methodIndex = CodeReader.ReadInt32();
                    Method ctor = (Method)method.Executable.Pool[methodIndex];
                    Emit(bytecode,ctor.Parameters.Count-1,true);
                    break;
                }
                case Bytecode.OpLoadImmediateDouble:
                {
                    Emit(bytecode, 0, true,CodeReader.ReadDouble());
                    break;
                }
                case Bytecode.OpLoadImmediateFloat:
                {
                    Emit(bytecode, 0, true,CodeReader.ReadSingle());
                    break;
                }
                case Bytecode.OpLoadImmediateInt64:
                {
                    Emit(bytecode, 0, true,CodeReader.ReadInt64());
                    break;
                }
                case Bytecode.OpLoadImmediateInt32:
                {
                    Emit(bytecode, 0, true,CodeReader.ReadInt32());
                    break;
                }
                case Bytecode.OpLoadFloatFromArray:
                case Bytecode.OpLoadInt64FromArray:
                case Bytecode.OpLoadInt32FromArray:
                case Bytecode.OpLoadInt16FromArray:
                case Bytecode.OpLoadDoubleFromArray:
                case Bytecode.OpLoadInt8FromArray:
                case Bytecode.OpLoadObjectFromArray:
                case Bytecode.OpLoadNativeIntFromArray:
                {
                    Emit(bytecode,2,true);
                    break;
                }
                case Bytecode.OpLoadArrayLength:
                {
                    Emit(bytecode,1,true);
                    break;
                }
                case Bytecode.OpStoreObjectToArray:
                case Bytecode.OpStoreDoubleToArray:
                case Bytecode.OpStoreFloatToArray:
                case Bytecode.OpStoreInt64ToArray:
                case Bytecode.OpStoreInt32ToArray:
                case Bytecode.OpStoreInt16ToArray:
                case Bytecode.OpStoreInt8ToArray:
                case Bytecode.OpStoreNativeIntToArray:
                {
                    Emit(bytecode,3,true);
                    break;
                }
                case Bytecode.OpBranchIfNonZero:
                case Bytecode.OpBranchIfZero:
                {
                    Emit(bytecode,1,false,CodeReader.ReadInt32());
                    break;
                }
                case Bytecode.OpBranchIfUnequalUnordered:
                case Bytecode.OpBranchIfLess:
                case Bytecode.OpBranchIfLessOrEqual:
                case Bytecode.OpBranchIfGreaterOrEqual:
                case Bytecode.OpBranchIfGreater:
                case Bytecode.OpBranchIfEquals:
                {
                    Emit(bytecode,2,false,CodeReader.ReadInt32());
                    break;
                }
                case Bytecode.OpBranch:
                {
                    Emit(bytecode,0,false,CodeReader.ReadInt32());
                    break;
                }
                case Bytecode.OpPushOneIfLowerUn:
                case Bytecode.OpPushOneIfGreaterUn:
                case Bytecode.OpPushOneIfLower:
                case Bytecode.OpPushOneIfGreater:
                case Bytecode.OpPushOneIfEqual:
                {
                    Emit(bytecode,2,true);
                    break;
                }
                case Bytecode.OpCall:
                {
                    int methodIndex = CodeReader.ReadInt32();
                    Method callTarget = (Method)method.Executable.Pool[methodIndex];
                    Emit(bytecode,callTarget.Parameters.Count,callTarget.Return.FullName != "System.Void");
                    break;
                }
                case Bytecode.OpVirtualCall:
                {
                    int methodIndex = CodeReader.ReadInt32();
                    Method callTarget = (Method)method.Executable.Pool[methodIndex];
                    Emit(bytecode,callTarget.Parameters.Count,callTarget.Return.FullName != "System.Void");
                    break;
                }
                case Bytecode.OpReturn:
                {
                    bool isReturn = method.Return.FullName != "System.Void";
                    if (isReturn)
                    {
                        Emit(bytecode,1,false);                        
                    }
                    else
                    {
                        Emit(bytecode,0,false);
                    }
                    break;
                }
                case Bytecode.OpIsInstance:
                {
                    int index = CodeReader.ReadInt32();
                    Type value = (Type)method.Executable.Pool[index];
                    Emit(bytecode,1,true,value);
                    break;
                }
                case Bytecode.OpCastClass:
                {
                    int index = CodeReader.ReadInt32();
                    Type value = (Type)method.Executable.Pool[index];
                    Emit(bytecode,1,false,value);
                    break;
                }
                case Bytecode.OpBox:
                {
                    int index = CodeReader.ReadInt32();
                    Type value = (Type)method.Executable.Pool[index];
                    Emit(bytecode,1,true,value);
                    break;
                }
                case Bytecode.OpUnboxToPointer:
                {
                    Emit(bytecode,1,true);
                    break;
                }
                case Bytecode.OpUnboxToValue:
                {
                    Emit(bytecode,1,true);
                    break;
                }
                case Bytecode.OpThrowException:
                {
                    Emit(bytecode,1,false);
                    break;
                }
                case Bytecode.OpEndFinallyException:
                {
                    Emit(bytecode);
                    break;
                }
                case Bytecode.OpRethrowException:
                {
                    Emit(bytecode,1,true);
                    break;
                }
                case Bytecode.OpLeaveException:
                {
                    Emit(bytecode);
                    break;
                }
                default:
                {
                    throw new Exception("Bad bytecode!");
                }
            }

            previousBytecode = bytecode;
        }

        foreach (Instruction instruction in Instructions)
        {
            switch (instruction.Bytecode)
            {
                case Bytecode.OpBranchIfNonZero:
                case Bytecode.OpBranchIfZero:
                {
                    instruction.Immediate = Locate((int)instruction.Immediate);
                    break;
                }
                case Bytecode.OpBranchIfUnequalUnordered:
                case Bytecode.OpBranchIfLess:
                case Bytecode.OpBranchIfLessOrEqual:
                case Bytecode.OpBranchIfGreaterOrEqual:
                case Bytecode.OpBranchIfGreater:
                case Bytecode.OpBranchIfEquals:
                {
                    instruction.Immediate = Locate((int)instruction.Immediate);
                    break;
                }
                case Bytecode.OpBranch:
                {
                    instruction.Immediate = Locate((int)instruction.Immediate);
                    break;
                }
            }
        }
    }
}