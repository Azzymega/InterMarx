﻿namespace Internationale.VKP.May.Machine;

public class RiscRegisterAllocator
{
    public Register FramePointer { get; private set; }
    public Register StackPointer { get; private set; }
    public Register GlobalPointer { get; private set; }
    public int Count => _allocated.Count + _free.Count + 3;

    private readonly List<Register> _allocated;
    private readonly List<Register> _free;
    private readonly RiscGenerator _generator;
    private readonly List<Register> _spilled;
    private readonly Dictionary<Register, Register> _translationTable;
    
    public RiscRegisterAllocator(int registerCount, RiscGenerator generator)
    {
        _generator = generator;
        _allocated = new List<Register>();
        _free = new List<Register>();
        _spilled = new List<Register>();
        _translationTable = new Dictionary<Register, Register>();

        if (registerCount <= 3)
        {
            throw new ArgumentException("Not enough registers!");
        }

        FramePointer = new Register(0);
        StackPointer = new Register(1);
        GlobalPointer = new Register(2);
        
        registerCount -= 3;
        for (int i = 0; i < registerCount; i++)
        {
            _free.Add(new Register(3+i));
        }

        int registerCarousel = 0;
        for (int i = 0; i < _generator.Translator.StackMachine.Registers.Count; i++)
        {
            Register virtualRegister = generator.Translator.StackMachine.Registers[i];
            Register physicalRegister = _free[registerCarousel++];
            if (registerCarousel >= _free.Count)
            {
                registerCarousel = 0;
            }
            _translationTable.Add(virtualRegister,physicalRegister);
        }
    }

    public void Deallocate(Register register)
    {
        _free.Add(register);
        _allocated.Remove(register);
    }

    public Register Allocate()
    {
        if (_free.Count == 0)
        {
            Register spillTarget = _allocated[0];
            foreach (var slot in _generator.StackFrame.Spills)
            {
                if (slot.Owner.Equals(spillTarget))
                {
                    _generator.Spill(spillTarget,slot);
                }
            }
            return spillTarget;
        }
        else
        {
            Register freeRegister = _free[_free.Count-1];
            _free.Remove(freeRegister);
            _allocated.Add(freeRegister);
            return freeRegister;
        }
    }
    
    public Register[] Allocate(int count)
    {
        if (count >= Count)
        {
            throw new ArgumentException("Not enough register!");
        }
        
        if (_free.Count <= count)
        {
            Register[] registers = new Register[count];
            for (int i = 0; i < registers.Length; i++)
            {
                Register spillTarget = _allocated[i];
                foreach (var slot in _generator.StackFrame.Spills)
                {
                    if (slot.Owner.Equals(spillTarget))
                    {
                        _generator.Spill(spillTarget,slot);
                    }
                }

                registers[i] = spillTarget;
            }
            return registers;
        }
        else
        {
            Register[] registers = new Register[count];
            for (int i = 0; i < registers.Length; i++)
            {
                registers[i] = _free[i];
                _free.Remove(registers[i]);
                _allocated.Add(registers[i]);
            }
            return registers;
        }
    }
    
    public void Reload()
    {
        foreach (var register in _spilled)
        {
            foreach (var slot in _generator.StackFrame.Spills)
            {
                if (slot.Owner.Equals(register))
                {
                    _generator.Reload(register,slot);
                }
            }
        }
        _spilled.Clear();
    }
}