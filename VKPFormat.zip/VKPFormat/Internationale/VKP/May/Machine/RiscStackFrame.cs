﻿using Mono.Cecil;

namespace Internationale.VKP.May.Machine;

public class RiscStackFrame
{
    public List<RiscSlot> Slots { get; set; }
    public List<RiscSlot> Spills { get; set; }
    private RiscGenerator _generator;

    public RiscStackFrame(RiscGenerator generator)
    {
        _generator = generator;
        Spills = new List<RiscSlot>();
        Slots = new List<RiscSlot>();

        int offsetLength = 0;
        for (int i = 0; i < _generator.Translator.Method.Executable.Variables.Count; i++)
        {
            TypeDefinition value = generator.Translator.Method.Executable.Variables[i].Definition;
            RiscSlot slot = new RiscSlot(new Register(i),offsetLength);
            Slots.Add(slot);
            offsetLength += value.ClassSize;
        }

        for (int i = 0; i < _generator.RegisterAllocator.Count; i++)
        {
            RiscSlot slot = new RiscSlot(new Register(i),offsetLength);
            Spills.Add(slot);
            offsetLength += 4;
        }
    }
}