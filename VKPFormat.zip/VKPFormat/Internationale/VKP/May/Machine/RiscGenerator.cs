﻿using Internationale.VKP.Image.Code;

namespace Internationale.VKP.May.Machine;

public class RiscGenerator
{
    public RiscRegisterAllocator RegisterAllocator { get; private set; }
    public RiscStackFrame StackFrame { get; private set; }
    public RegisterTranslator Translator { get; private set; }
    
    private List<RiscInstruction> _output;

    public RiscGenerator(RegisterTranslator translator)
    {
        Translator = translator;
        RegisterAllocator = new RiscRegisterAllocator(7,this);
        StackFrame = new RiscStackFrame(this);
        _output = new List<RiscInstruction>();
    }

    public void Emit(RiscOpcode opcode, Register dest, Register source, object immediate)
    {
        RiscInstruction instruction = new RiscInstruction(opcode,dest,source,immediate);
        _output.Add(instruction);
    }

    public void Emit(RiscOpcode opcode, Register dest, Register source, Register secondSource)
    {
        RiscInstruction instruction = new RiscInstruction(opcode,dest,source,secondSource);
        _output.Add(instruction);
    }

    public void Emit(RiscOpcode opcode)
    {
        RiscInstruction instruction = new RiscInstruction(opcode,null,null,null);
        _output.Add(instruction);
    }
    
    public void Compile()
    {
        foreach (var instruction in Translator.Instructions)
        {
            switch (instruction.Bytecode)
            {
                case Bytecode.OpBreakpoint:
                {
                    Emit(RiscOpcode.Debug);
                    break;
                }
                case Bytecode.OpNoOperation:
                {
                    Emit(RiscOpcode.Addi,RegisterAllocator.GlobalPointer,RegisterAllocator.GlobalPointer,0);
                    break;
                }
                case Bytecode.OpAdd:
                {
                    
                    break;
                }
                case Bytecode.OpSub:
                    break;
                case Bytecode.OpMu:
                    break;
                case Bytecode.OpDiv:
                    break;
                case Bytecode.OpRem:
                    break;
                case Bytecode.OpNeg:
                    break;
                case Bytecode.OpAnd:
                    break;
                case Bytecode.OpOr:
                    break;
                case Bytecode.OpXor:
                    break;
                case Bytecode.OpNot:
                    break;
                case Bytecode.OpShiftLeft:
                    break;
                case Bytecode.OpShiftRight:
                    break;
                case Bytecode.OpConvertI8:
                    break;
                case Bytecode.OpConvertI16:
                    break;
                case Bytecode.OpConvertI32:
                    break;
                case Bytecode.OpConvertI64:
                    break;
                case Bytecode.OpConvertFloat:
                    break;
                case Bytecode.OpConvertDouble:
                    break;
                case Bytecode.OpConvertIntPtr:
                    break;
                case Bytecode.OpLoadValueFieldAddress:
                    break;
                case Bytecode.OpLoadLocalVariableAddress:
                    break;
                case Bytecode.OpLoadArgumentAddress:
                    break;
                case Bytecode.OpLoadValueFromPointer:
                    break;
                case Bytecode.OpStoreValueToPointer:
                    break;
                case Bytecode.OpLoadAddressOfArrayElement:
                    break;
                case Bytecode.OpLoadValueField:
                    break;
                case Bytecode.OpLoadStaticField:
                    break;
                case Bytecode.OpStoreValueField:
                    break;
                case Bytecode.OpStoreStaticField:
                    break;
                case Bytecode.OpLoadArgument:
                    break;
                case Bytecode.OpStoreArgument:
                    break;
                case Bytecode.OpLoadLocal:
                    break;
                case Bytecode.OpStoreLocal:
                    break;
                case Bytecode.OpLoadNull:
                    break;
                case Bytecode.OpLoadString:
                    break;
                case Bytecode.OpLoadMethodDescriptor:
                    break;
                case Bytecode.OpLoadVirtualMethodDescriptor:
                    break;
                case Bytecode.OpNewArray:
                    break;
                case Bytecode.OpInitializeObject:
                    break;
                case Bytecode.OpNewObject:
                    break;
                case Bytecode.OpLoadImmediateInt32:
                    break;
                case Bytecode.OpLoadImmediateInt64:
                    break;
                case Bytecode.OpLoadImmediateFloat:
                    break;
                case Bytecode.OpLoadImmediateDouble:
                    break;
                case Bytecode.OpLoadNativeIntFromArray:
                    break;
                case Bytecode.OpLoadInt8FromArray:
                    break;
                case Bytecode.OpLoadInt16FromArray:
                    break;
                case Bytecode.OpLoadInt32FromArray:
                    break;
                case Bytecode.OpLoadInt64FromArray:
                    break;
                case Bytecode.OpLoadFloatFromArray:
                    break;
                case Bytecode.OpLoadDoubleFromArray:
                    break;
                case Bytecode.OpLoadObjectFromArray:
                    break;
                case Bytecode.OpLoadArrayLength:
                    break;
                case Bytecode.OpStoreNativeIntToArray:
                    break;
                case Bytecode.OpStoreInt8ToArray:
                    break;
                case Bytecode.OpStoreInt16ToArray:
                    break;
                case Bytecode.OpStoreInt32ToArray:
                    break;
                case Bytecode.OpStoreInt64ToArray:
                    break;
                case Bytecode.OpStoreFloatToArray:
                    break;
                case Bytecode.OpStoreDoubleToArray:
                    break;
                case Bytecode.OpStoreObjectToArray:
                    break;
                case Bytecode.OpBranchIfEquals:
                    break;
                case Bytecode.OpBranchIfGreaterOrEqual:
                    break;
                case Bytecode.OpBranchIfGreater:
                    break;
                case Bytecode.OpBranchIfLessOrEqual:
                    break;
                case Bytecode.OpBranchIfLess:
                    break;
                case Bytecode.OpBranchIfZero:
                    break;
                case Bytecode.OpBranchIfNonZero:
                    break;
                case Bytecode.OpBranch:
                    break;
                case Bytecode.OpBranchIfUnequalUnordered:
                    break;
                case Bytecode.OpPushOneIfEqual:
                    break;
                case Bytecode.OpPushOneIfGreater:
                    break;
                case Bytecode.OpPushOneIfLower:
                    break;
                case Bytecode.OpPushOneIfGreaterUn:
                    break;
                case Bytecode.OpPushOneIfLowerUn:
                    break;
                case Bytecode.OpCall:
                    break;
                case Bytecode.OpVirtualCall:
                    break;
                case Bytecode.OpReturn:
                    break;
                case Bytecode.OpIsInstance:
                    break;
                case Bytecode.OpCastClass:
                    break;
                case Bytecode.OpBox:
                    break;
                case Bytecode.OpUnboxToPointer:
                    break;
                case Bytecode.OpUnboxToValue:
                    break;
                case Bytecode.OpThrowException:
                    break;
                case Bytecode.OpEndFinallyException:
                    break;
                case Bytecode.OpRethrowException:
                    break;
                case Bytecode.OpLeaveException:
                    break;
                case Bytecode.OpMove:
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
            
            RegisterAllocator.Reload();
        }
    }

    public void Spill(Register register, RiscSlot slot)
    {
        RiscInstruction instruction = new RiscInstruction(RiscOpcode.StoreInt32,RegisterAllocator.FramePointer,register,-slot.FrameOffset);
    }
    
    public void Reload(Register register, RiscSlot slot)
    {
        RiscInstruction instruction = new RiscInstruction(RiscOpcode.LoadInt32,register,RegisterAllocator.FramePointer,-slot.FrameOffset);
    }
}