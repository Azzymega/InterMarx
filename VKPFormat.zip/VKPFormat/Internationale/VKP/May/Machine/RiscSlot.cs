﻿namespace Internationale.VKP.May.Machine;

public class RiscSlot
{
    public int FrameOffset { get; private set; }
    public Register Owner { get; private set; }
    
    public RiscSlot(Register owner, int frameOffset)
    {
        Owner = owner;
        FrameOffset = frameOffset;
    }
}