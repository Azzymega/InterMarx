﻿namespace Internationale.VKP.May.Machine;

public enum RiscOpcode
{
    LoadInt32,
    LoadInt16,
    LoadByte,
    
    StoreInt32,
    StoreInt16,
    StoreByte,
    
    Add,
    Addi,
    Subtract,
    Subi,
    Divide,
    Multiply,
    Remainder,
    
    And,
    Or,
    Xor,
    
    LogicalLeftShift,
    LogicalRightShift,
    
    EqualBranch,
    NonEqualBranch,
    BiggerBranch,
    BiggerEqualsBranch,
    LowerBranch,
    LowerEqualsBranch,
    
    Call,
    Ret,
    Debug,
}