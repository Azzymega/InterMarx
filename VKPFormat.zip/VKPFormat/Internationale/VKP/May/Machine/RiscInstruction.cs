﻿namespace Internationale.VKP.May.Machine;

public class RiscInstruction
{
    private RiscOpcode _opcode;
    private Register _dest;
    private Register _firstSource;
    private Register _secondSource;
    private object _immediate;

    public RiscInstruction(RiscOpcode opcode, Register dest, Register firstSource, object immediate)
    {
        _opcode = opcode;
        _dest = dest;
        _firstSource = firstSource;
        _immediate = immediate;
    }
    
    public RiscInstruction(RiscOpcode opcode, Register dest, Register firstSource, Register secondSource)
    {
        _opcode = opcode;
        _dest = dest;
        _firstSource = firstSource;
        _secondSource = secondSource;
    }

    public RiscOpcode Opcode
    {
        get => _opcode;
        set => _opcode = value;
    }

    public Register Dest
    {
        get => _dest;
        set => _dest = value ?? throw new ArgumentNullException(nameof(value));
    }

    public Register FirstSource
    {
        get => _firstSource;
        set => _firstSource = value ?? throw new ArgumentNullException(nameof(value));
    }

    public Register SecondSource
    {
        get => _secondSource;
        set => _secondSource = value ?? throw new ArgumentNullException(nameof(value));
    }

    public object Immediate
    {
        get => _immediate;
        set => _immediate = value ?? throw new ArgumentNullException(nameof(value));
    }
}