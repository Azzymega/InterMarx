﻿namespace Internationale.VKP.Image.Code;

public enum Bytecode : Byte
{
    OpBreakpoint,
    OpNoOperation,
    
    OpDup,
    OpPop,
    
    OpAdd,
    OpSub,
    OpMu,
    OpDiv,
    OpRem,
    OpNeg,
    
    OpAnd,
    OpOr,
    OpXor,
    OpNot,
    
    OpShiftLeft,
    OpShiftRight,
    
    OpConvertI8,
    OpConvertI16,
    OpConvertI32,
    OpConvertI64,
    OpConvertFloat,
    OpConvertDouble,
    OpConvertIntPtr,

    OpLoadValueFieldAddress,
    OpLoadLocalVariableAddress,
    OpLoadArgumentAddress,
    OpLoadValueFromPointer,
    OpStoreValueToPointer,
    OpLoadAddressOfArrayElement,
    
    OpLoadValueField,
    OpLoadStaticField,
    OpStoreValueField,
    OpStoreStaticField,
    
    OpLoadArgument,
    OpStoreArgument,
    OpLoadLocal,
    OpStoreLocal,
    
    OpLoadNull,
    OpLoadString,
    OpLoadMethodDescriptor,
    OpLoadVirtualMethodDescriptor,
    
    OpNewArray,
    OpInitializeObject,
    OpNewObject,
    
    OpLoadImmediateInt32,
    OpLoadImmediateInt64,
    OpLoadImmediateFloat,
    OpLoadImmediateDouble,
    
    OpLoadNativeIntFromArray,
    OpLoadInt8FromArray,
    OpLoadInt16FromArray,
    OpLoadInt32FromArray,
    OpLoadInt64FromArray,
    OpLoadFloatFromArray,
    OpLoadDoubleFromArray,
    OpLoadObjectFromArray,
    
    OpLoadArrayLength,
    
    OpStoreNativeIntToArray,
    OpStoreInt8ToArray,
    OpStoreInt16ToArray,
    OpStoreInt32ToArray,
    OpStoreInt64ToArray,
    OpStoreFloatToArray,
    OpStoreDoubleToArray,
    OpStoreObjectToArray,

    OpBranchIfEquals,
    OpBranchIfGreaterOrEqual,
    OpBranchIfGreater,
    OpBranchIfLessOrEqual,
    OpBranchIfLess, 
    OpBranchIfZero,
    OpBranchIfNonZero,
    OpBranch,
    
    OpBranchIfUnequalUnordered,
    
    OpPushOneIfEqual,
    OpPushOneIfGreater,
    OpPushOneIfLower,
    OpPushOneIfGreaterUn,
    OpPushOneIfLowerUn,
        
    OpCall,
    OpVirtualCall,
    OpReturn,
    
    OpIsInstance,
    OpCastClass,
    
    OpBox,
    OpUnboxToPointer,
    OpUnboxToValue,
    
    OpThrowException,
    OpEndFinallyException,
    OpRethrowException,
    OpLeaveException,
    
    // Extensions
    
    OpMove,
}