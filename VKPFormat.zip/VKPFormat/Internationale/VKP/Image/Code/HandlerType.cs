﻿namespace Internationale.VKP.Image.Code;

public enum HandlerType
{
    Unknown,
    Catch,
    Finally,
}