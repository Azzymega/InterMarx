﻿using System.Numerics;
using Mono.Cecil.Cil;

namespace Internationale.VKP.Image.Code;

public class BranchMachine
{
    public Dictionary<Instruction, int> InstructionOffsets { get; set; }
    public Dictionary<Instruction, int> BranchesOffsets { get; set; }
    public BinaryWriter Writer { get; set; }
    public List<byte> Target { get; set; }
    public MemoryStream Stream { get; set; }

    public BranchMachine(List<byte> bytecode)
    {
        Target = bytecode;
        InstructionOffsets = new Dictionary<Instruction, int>();
        BranchesOffsets = new Dictionary<Instruction, int>();
    }

    public void Load(Instruction instruction, int offset)
    {
        InstructionOffsets.Add(instruction,offset);
    }

    public void RegisterBranch(Instruction branch, int streamOffset)
    {
        BranchesOffsets.Add(branch,streamOffset);
    }

    public void Fix()
    {
        Stream = new MemoryStream(Target.ToArray());
        Writer = new BinaryWriter(Stream);
        long currentPosition = Writer.BaseStream.Position;
        foreach (var branchesOffset in BranchesOffsets)
        {
            Instruction branchTarget = (Instruction)branchesOffset.Key.Operand;
            Writer.BaseStream.Position = branchesOffset.Value;
            Writer.Write(InstructionOffsets[branchTarget]);
        }
        Writer.BaseStream.Position = currentPosition;
        Target.Clear();
        Target.AddRange(Stream.ToArray());
    }
}