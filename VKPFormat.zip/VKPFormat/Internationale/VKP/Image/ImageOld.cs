﻿using Internationale.VKP.Image.Code;
using Internationale.VKP.Image.Sections;
using Internationale.VKP.Serializer.Attributes;
using Mono.Cecil;
using Attribute = Internationale.VKP.Image.Sections.Attribute;

namespace Internationale.VKP.Image;

using Type = Sections.Type;

public class ImageOld
{
    public int Magic { get; set; } = 0x50C1A715;
    public List<Section> Sections { get; set; }
    [Ignore] public Strings Table => (Strings)Sections[1];

    public ImageOld(AssemblyDefinition definition)
    {
        Sections = new List<Section>
        {
            new Header(definition.MainModule.RuntimeVersion),
            new Strings()
        };
    }

    public void Initialize(AssemblyDefinition definition)
    {
        foreach (var module in definition.Modules)
        {
            foreach (var typeDefinition in module.Types)
            {
                if (typeDefinition.FullName.Contains("<Module>"))
                {
                    continue;
                }

                if (typeDefinition.BaseType == null)
                {
                    Type value = Get(typeDefinition);
                    Register(value);
                }
            }
        }

        foreach (var module in definition.Modules)
        {
            foreach (var typeDefinition in module.Types)
            {
                if (typeDefinition.FullName.Contains("<Module>"))
                {
                    continue;
                }

                Type target = Get(typeDefinition);
                if (typeDefinition.BaseType == null)
                {
                    continue;
                }

                Stack<Type> types = new Stack<Type>();

                types.Push(target);

                TypeReference baseType = typeDefinition.BaseType;

                while (baseType != null)
                {
                    if (baseType.IsDefinition)
                    {
                        TypeDefinition currentDef = (TypeDefinition)baseType;
                        Type top = types.Peek();
                        types.Push(new Type(currentDef));
                        top.Base = types.Peek();
                        baseType = currentDef.BaseType;
                    }
                    else
                    {
                        // TODO IMPORT IS NEEDED???
                        //throw new ArgumentException("Strange type!");

                        Type top = types.Peek();
                        types.Push(new Type(baseType));
                        top.Base = types.Peek();
                        break;
                    }
                }

                foreach (var type in types)
                {
                    Register(type);
                }
            }
        }

        foreach (var module in definition.Modules)
        {
            foreach (var typeDefinition in module.Types)
            {
                if (typeDefinition.FullName.Contains("<Module>"))
                {
                    continue;
                }

                Type target = Get(typeDefinition);
                foreach (var fieldValue in typeDefinition.Fields)
                {
                    Field field = new Field(fieldValue)
                    {
                        Owner = target,
                        Declared = Get(fieldValue.FieldType)
                    };
                    Register(field);
                }
            }
        }

        foreach (var module in definition.Modules)
        {
            foreach (var typeDefinition in module.Types)
            {
                if (typeDefinition.FullName.Contains("<Module>"))
                {
                    continue;
                }

                Type target = Get(typeDefinition);
                foreach (var methodValue in typeDefinition.Methods)
                {
                    Method method = new Method(methodValue)
                    {
                        Owner = target,
                        Return = Get(methodValue.ReturnType)
                    };
                    if (!methodValue.IsStatic)
                    {
                        method.Parameters.Add(method.Owner);
                    }

                    foreach (var parameter in methodValue.Parameters)
                    {
                        method.Parameters.Add(Get(parameter.ParameterType));
                    }

                    Register(method);
                }
            }
        }

        foreach (var module in definition.Modules)
        {
            foreach (var typeDefinition in module.Types)
            {
                if (typeDefinition.FullName.Contains("<Module>"))
                {
                    continue;
                }

                // Type target = Get(typeDefinition);
                // foreach (var methodValue in typeDefinition.Methods)
                // {
                //     Method info = Get(methodValue);
                //     if (!info.Characteristics.HasFlag(Characteristics.Extern))
                //     {
                //         ILTranslator writer = new ILTranslator(this, methodValue, info);
                //         writer.Compile();
                //         foreach (var variable in methodValue.Body.Variables)
                //         {
                //             info.Executable.Variables.Add(Get(variable.VariableType));
                //         }
                //
                //         Register(writer.Target.Executable);
                //     }
                // }
            }
        }

        // foreach (var module in definition.Modules)
        // {
        //     foreach (var typeDefinition in module.Types)
        //     {
        //         if (typeDefinition.FullName.Contains("<Module>"))
        //         {
        //             continue;
        //         }
        //
        //         Type target = Get(typeDefinition);
        //         foreach (var attribute in typeDefinition.CustomAttributes)
        //         {
        //             Register(new Attribute(attribute, target, this));
        //         }
        //
        //         foreach (var fieldValue in typeDefinition.Fields)
        //         {
        //             Field info = Get(fieldValue);
        //             foreach (var attribute in fieldValue.CustomAttributes)
        //             {
        //                 Register(new Attribute(attribute, info, this));
        //             }
        //         }
        //
        //         foreach (var methodValue in typeDefinition.Methods)
        //         {
        //             Method info = Get(methodValue);
        //             foreach (var attribute in methodValue.CustomAttributes)
        //             {
        //                 Register(new Attribute(attribute, info, this));
        //             }
        //         }
        //     }
        // }

        List<Argument> createdArguments = new List<Argument>();
        foreach (var module in definition.Modules)
        {
            foreach (var typeDefinition in module.Types)
            {
                if (typeDefinition.FullName.Contains("<Module>"))
                {
                    continue;
                }

                Type target = Get(typeDefinition);

                foreach (var section in Sections)
                {
                    if (section.GetType() == SectionType.Attribute)
                    {
                        Attribute attribute = (Attribute)section;
                        if (attribute.Owner.Equals(target))
                        {
                            foreach (var customAttribute in typeDefinition.CustomAttributes)
                            {
                                if (Get(customAttribute.AttributeType).Equals(attribute.Declared))
                                {
                                    foreach (var argument in customAttribute.ConstructorArguments)
                                    {
                                        // createdArguments.Add(new Argument(argument, attribute, this));
                                    }
                                }
                            }
                        }
                    }
                }

                foreach (var fieldValue in typeDefinition.Fields)
                {
                    Field info = Get(fieldValue);

                    foreach (var section in Sections)
                    {
                        if (section.GetType() == SectionType.Attribute)
                        {
                            Attribute attribute = (Attribute)section;
                            if (attribute.Owner.Equals(info))
                            {
                                //     foreach (var customAttribute in fieldValue.CustomAttributes)
                                //     {
                                //         if (Get(customAttribute.AttributeType).Equals(attribute.Declared))
                                //         {
                                //             foreach (var argument in customAttribute.ConstructorArguments)
                                //             {
                                //                 createdArguments.Add(new Argument(argument, attribute, this));
                                //             }
                                //         }
                                //     }
                                // }
                            }
                        }
                    }
                }

                foreach (var methodValue in typeDefinition.Methods)
                {
                    Method info = Get(methodValue);

                    foreach (var section in Sections)
                    {
                        if (section.GetType() == SectionType.Attribute)
                        {
                            Attribute attribute = (Attribute)section;
                            if (attribute.Owner.Equals(info))
                            {
                                foreach (var customAttribute in methodValue.CustomAttributes)
                                {
                                    if (Get(customAttribute.AttributeType).Equals(attribute.Declared))
                                    {
                                        foreach (var argument in customAttribute.ConstructorArguments)
                                        {
                                            // createdArguments.Add(new Argument(argument, attribute, this));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        foreach (var createdArgument in createdArguments)
        {
            Register(createdArgument);
        }
    }

    public Type Get(TypeDefinition definition)
    {
        Type value = Locate(definition);

        if (value == null)
        {
            throw new ArgumentException($"Type {definition.FullName} not found!");
        }
        
        return value;
    }

    public Type Get(TypeReference reference)
    {
        Type value = Locate(reference);
        
        if (value == null)
        {
            throw new ArgumentException($"Type {reference.FullName} not found!");
        }

        return value;
    }

    public Field Get(FieldReference reference)
    {
        Field data = Locate(reference);

        if (data == null)
        {
            throw new ArgumentException($"Field {reference.FullName} not found!");
        }

        return data;
    }

    public Field Get(FieldDefinition definition)
    {
        Field data = Locate(definition);
        
        if (data == null)
        {
            throw new ArgumentException($"Field {definition.FullName} not found!");
        }

        return data;
    }

    public Method Get(MethodDefinition definition)
    {
        Method target = Locate(definition);
        
        if (target == null)
        {
            throw new ArgumentException($"Field {definition.FullName} not found!");
        }

        return target;
    }

    public Method Get(MethodReference definition)
    {
        Method target = Locate(definition);
        
        if (target == null)
        {
            throw new ArgumentException($"Field {definition.FullName} not found!");
        }
        
        return target;
    }


    public int IndexOf(Section section)
    {
        return Sections.IndexOf(section);
    }

    public Field Locate(FieldDefinition definition)
    {
        foreach (var section in Sections)
        {
            if (section is Field)
            {
                Field field = (Field)section;
                if (field.Owner.FullName == definition.DeclaringType.FullName && field.ShortName == definition.Name)
                {
                    return field;
                }
            }
        }

        return null;
    }

    public Type Locate(TypeReference definition)
    {
        foreach (var section in Sections)
        {
            if (section is Type)
            {
                Type value = (Type)section;
                if (value.FullName == definition.FullName)
                {
                    return value;
                }
                else if (value.Reference == definition)
                {
                    return value;
                }
                else if (value.Definition == definition)
                {
                    return value;
                }
            }
        }

        return null;
    }

    public Method Locate(MethodDefinition definition)
    {
        foreach (var section in Sections)
        {
            if (section is Method)
            {
                Method method = (Method)section;
                if (method.Owner.FullName == definition.DeclaringType.FullName)
                {
                    if (method.FullName == definition.FullName)
                    {
                        return method;
                    }
                    else if (method.Definition == definition)
                    {
                        return method;
                    }
                }
            }
        }

        return null;
    }

    public Field Locate(FieldReference definition)
    {
        foreach (var section in Sections)
        {
            if (section is Field)
            {
                Field field = (Field)section;
                if (field.Owner.FullName == definition.DeclaringType.FullName && field.ShortName == definition.Name)
                {
                    return field;
                }
                else if (field.Reference == definition)
                {
                    return field;
                }
                else if (field.Definition == definition)
                {
                    return field;
                }
            }
        }

        return null;
    }

    public Method Locate(MethodReference definition)
    {
        foreach (var section in Sections)
        {
            if (section is Method)
            {
                Method method = (Method)section;
                if (method.Owner.FullName == definition.DeclaringType.FullName)
                {
                    if (method.FullName == definition.FullName)
                    {
                        return method;
                    }
                }
            }
        }

        return null;
    }

    public void Register(TypeDefinition definition)
    {
        Sections.Add(new Type(definition));
    }

    public void Register(TypeReference definition)
    {
        Sections.Add(new Type(definition));
    }

    public void Register(Argument argument)
    {
        Sections.Add(argument);
    }

    public void Register(Field field)
    {
        foreach (var section in Sections)
        {
            if (section is Field target)
            {
                if (field.FullName == target.FullName)
                {
                    return;
                }
            }
        }

        Sections.Add(field);
    }

    public void Register(Method method)
    {
        foreach (var section in Sections)
        {
            if (section is Method target)
            {
                if (method.FullName == target.FullName)
                {
                    return;
                }
            }
        }

        Sections.Add(method);
    }

    public void Register(Type type)
    {
        foreach (var section in Sections)
        {
            if (section is Type target)
            {
                if (type.FullName == target.FullName)
                {
                    return;
                }
            }
        }

        Sections.Add(type);
    }

    public void Register(Executable executable)
    {
        Sections.Add(executable);
    }

    public void Register(Attribute definition)
    {
        Sections.Add(definition);
    }

    public void Register(Handler definition)
    {
        Sections.Add(definition);
    }
}