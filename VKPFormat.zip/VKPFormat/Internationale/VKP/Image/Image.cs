﻿using Internationale.VKP.Image.Code;
using Internationale.VKP.Image.Sections;
using Internationale.VKP.Serializer.Attributes;
using Mono.Cecil;
using Attribute = Internationale.VKP.Image.Sections.Attribute;

namespace Internationale.VKP.Image;

using Type = Sections.Type;

public class Image
{
    public int Magic { get; set; } = 0x50C1A715;
    public List<Section> Sections { get; set; }
    [Ignore] public Strings Table => (Strings)Sections[1];

    public Image(AssemblyDefinition definition)
    {
        Sections = new List<Section>
        {
            new Header(definition.MainModule.RuntimeVersion),
            new Strings()
        };
    }

    public void Load(Compound.Compound compound)
    {
        Table.List.AddRange(compound.Table.List);
        
        Sections.AddRange(compound.TypeDefinitions);
        Sections.AddRange(compound.TypeImports);
        Sections.AddRange(compound.TypeGenerics);
        Sections.AddRange(compound.TypeAggregates);
        
        Sections.AddRange(compound.Arrays);
        Sections.AddRange(compound.Pointers);
        Sections.AddRange(compound.References);
        
        Sections.AddRange(compound.FieldDefinitions);
        Sections.AddRange(compound.FieldImports);
        Sections.AddRange(compound.FieldGenerics);
        
        Sections.AddRange(compound.MethodDefinitions);
        Sections.AddRange(compound.MethodImports);
        Sections.AddRange(compound.MethodGenerics);
        Sections.AddRange(compound.MethodExecutables);
        
        Sections.AddRange(compound.ExecutableHandlers);
        Sections.AddRange(compound.Attributes);
        Sections.AddRange(compound.Arguments);
        
        Repack();
        
        SortTypes();
        SortTypes();

        SortInterfaces();
        SortInterfaces();
    }

    private void Repack()
    {
        List<Type> interfaces = new List<Type>();
        foreach (var t in Sections)
        {
            if (t is Type type)
            {
                if (type.Characteristics.HasFlag(Characteristics.Interface))
                {
                    interfaces.Add(type);
                }
            }
        }
        
        foreach (var type in interfaces)
        {
            Sections.Remove(type);
        }
        
        Sections.InsertRange(2,interfaces);
        
        List<Type> aggregates = new List<Type>();
        foreach (var t in Sections)
        {
            if (t is Type type)
            {
                if (type.Characteristics.HasFlag(Characteristics.Aggregate))
                {
                    aggregates.Add(type);
                }
            }
        }
        
        foreach (var type in aggregates)
        {
            Sections.Remove(type);
        }
        
        Sections.InsertRange(2,aggregates);
    }

    private void SortInterfaces()
    {
        Second:
        for (int i = 0; i < Sections.Count; i++)
        {
            if (Sections[i] is Type type)
            {
                if (type.Characteristics.HasFlag(Characteristics.Interface))
                {
                    for (int j = 0; j < Sections.Count; j++)
                    {
                        if (Sections[j] is Type secondType)
                        {
                            if (secondType.Characteristics.HasFlag(Characteristics.Interface))
                            {
                                if (secondType == type)
                                {
                                    continue;
                                }

                                if (type.Base == secondType && i < j)
                                {
                                    Sections[i] = secondType;
                                    Sections[j] = type;
                                    goto Second;
                                }
                                else if (secondType.Base == type && j < i)
                                {
                                    Sections[j] = secondType;
                                    Sections[i] = type;
                                    goto Second;
                                }
                                if (type.Interfaces.Contains(secondType) && i < j)
                                {
                                    Sections[i] = secondType;
                                    Sections[j] = type;
                                    goto Second;
                                }
                                else if (secondType.Interfaces.Contains(type) && j < i)
                                {
                                    Sections[j] = secondType;
                                    Sections[i] = type;
                                    goto Second;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    private void SortTypes()
    {
        Start:
        for (int i = 0; i < Sections.Count; i++)
        {
            if (Sections[i] is Type firstType)
            {
                for (int j = 0; j < Sections.Count; j++)
                {
                    if (Sections[j] is Type secondType)
                    {
                        if (firstType.Base == null || firstType == secondType)
                        {
                            continue;
                        }
                        else if ((firstType.Base.FullName == secondType.FullName || firstType.Interfaces.Contains(secondType)) && i < j)
                        {
                            Sections[i] = secondType;
                            Sections[j] = firstType;
                            goto Start;
                        }
                        else if (secondType.Base == null)
                        {
                            continue;
                        }
                        else if ((secondType.Base.FullName == firstType.FullName || secondType.Interfaces.Contains(firstType)) && j < i)
                        {
                            Sections[j] = secondType;
                            Sections[i] = firstType;
                            goto Start;
                        }
                    }
                }                
            }
        }
    }
    
    public int IndexOf(Section section)
    {
        return Sections.IndexOf(section);
    }
}