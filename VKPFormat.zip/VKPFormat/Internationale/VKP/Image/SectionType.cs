﻿namespace Internationale.VKP.Image;

public enum SectionType
{
    Header,
    String,
    Type,
    Field,
    Method,
    Code,
    Handler,
    Attribute,
    Argument
}