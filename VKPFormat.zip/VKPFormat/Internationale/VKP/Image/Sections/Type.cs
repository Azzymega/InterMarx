﻿using System.Reflection.Metadata;
using System.Text;
using Internationale.VKP.Image.Util;
using Internationale.VKP.Serializer.Attributes;
using Mono.Cecil;
using GenericParameter = Mono.Cecil.GenericParameter;
using TypeDefinition = Mono.Cecil.TypeDefinition;
using TypeReference = Mono.Cecil.TypeReference;

namespace Internationale.VKP.Image.Sections;

public class Type : Section, ICloneable
{
    public SectionType Descriptor { get; set; }
    public string FullName { get; set; }
    public string ShortName { get; set; }
    public Type Base { get; set; }
    public List<Type> Interfaces { get; set; } = new List<Type>();
    public Characteristics Characteristics { get; set; }

    [Ignore] public List<Type> Arguments { get; set; } = new List<Type>();
    [Ignore] public List<Field> Fields { get; set; } = new List<Field>();
    [Ignore] public List<Method> Methods { get; set; } = new List<Method>();
    [Ignore] public TypeDefinition Definition { get; set; }
    [Ignore] public TypeReference Reference { get; set; }
    [Ignore] public GenericInstanceType Generic { get; set; }

    public override bool Equals(object? obj)
    {
        if (obj is Type type)
        {
            if (this.Characteristics == type.Characteristics && this.FullName == type.FullName)
            {
                return true;
            }
        }
        return false;
    }

    public void Subscribe(Field field)
    {
        foreach (var field1 in Fields)
        {
            if (field1.Definition == field.Definition)
            {
                return;
            }
            else if (field.FullName == field1.FullName)
            {
                return;
            }
        }
        Fields.Add(field);
    }

    public void Subscribe(Method method)
    {
        foreach (var method1 in Methods)
        { 
            if (method.FullName == method1.FullName)
            {
                return;
            }
        }
        Methods.Add(method);
    }

    public Method GetGenericBase(Method method)
    {
        foreach (var method1 in Methods)
        {
            if (method.ShortName == method1.ShortName)
            {
                if (method.Parameters.Count != method1.Parameters.Count)
                {
                    return null;
                }
                else
                {
                    if (method1.Characteristics.HasFlag(Characteristics.Static))
                    {
                        for (int i = 0; i < method.Parameters.Count; i++)
                        {
                            if (method.Parameters[i].FullName != method1.Parameters[i].FullName)
                            {
                                return null;
                            }
                        }
                    }
                    else
                    {
                        for (int i = 1; i < method.Parameters.Count; i++)
                        {
                            if (method.Parameters[i].FullName != method1.Parameters[i].FullName)
                            {
                                return null;
                            }
                        }
                    }

                    return method1;
                }
            }
        }

        return null;
    }
    
    
    public Field GetGenericBase(Field field)
    {
        foreach (var field1 in Fields)
        {
            if (field.ShortName == field1.ShortName)
            {
                return field1;
            }
        }

        return null;
    }
    
    public int IsFieldPresent(Field field)
    {
        for (int i = 0; i < Fields.Count; i++)
        {
            if (Fields[i].FullName == field.FullName && Fields[i] != field)
            {
                return i;
            }
        }

        return -1;
    }

    public int IsMethodPresent(Method method)
    {
        for (int i = 0; i < Methods.Count; i++)
        {
            if (Methods[i].FullName == method.FullName && Methods[i] != method)
            {
                return i;
            }
        }

        return -1;
    }
    
    private Type()
    {
        
    }
    
    public Type(TypeReference reference)
    {
        if (reference.IsGenericInstance)
        {
            GenericInstanceConstructor(reference as GenericInstanceType);
        }
        else if (reference is TypeDefinition definition)
        {
            DefinitionConstructor(definition);
        }
        else if (reference.IsArray)
        {
            ArrayConstructor(reference);
        }
        else if (reference.IsPointer)
        {
            PointerConstructor(reference);
        }
        else if (reference.IsByReference)
        {
            ByReferenceConstructor(reference);
        }
        else if (reference.IsGenericParameter)
        {
            GenericParameterConstructor(reference);
        }
        else
        {
            ReferenceConstructor(reference);
        }
    }
    
    private void ArrayConstructor(TypeReference reference)
    {
        Reference = reference;
        FullName = reference.FullName;
        ShortName = reference.Name;
        Descriptor = SectionType.Type;
        Characteristics = CharacteristicsUtil.Parse(reference);
    }

    private void PointerConstructor(TypeReference reference)
    {
        Reference = reference;
        FullName = reference.FullName;
        ShortName = reference.Name;
        Descriptor = SectionType.Type;
        Characteristics = Characteristics.Synthetic | Characteristics.Pointer;
    }
    
    private void ByReferenceConstructor(TypeReference reference)
    {
        Reference = reference;
        FullName = reference.FullName;
        ShortName = reference.Name;
        Descriptor = SectionType.Type;
        Characteristics = Characteristics.Synthetic | Characteristics.Reference;
    }

    private void GenericInstanceConstructor(GenericInstanceType definition)
    {
        Generic = definition;
        FullName = definition.FullName;
        ShortName = definition.Name;
        Descriptor = SectionType.Type;
        Characteristics = Util.CharacteristicsUtil.Parse(definition);
        Characteristics |= CharacteristicsUtil.Parse(definition.ElementType as TypeDefinition);

        bool final = true;
        foreach (var argument in definition.GenericArguments)
        {
            if (argument.IsGenericParameter)
            {
                final = false;
                if (!Characteristics.HasFlag(Characteristics.Template))
                {
                    Characteristics |= Characteristics.Template;
                }
            }
        }
        
        if (final && !Characteristics.HasFlag(Characteristics.Shapeshifter))
        {
            Characteristics |= Characteristics.Shapeshifter;
            
            if (Characteristics.HasFlag(Characteristics.Template))
            {
                Characteristics ^= Characteristics.Template;
            }
        }
        
        StringBuilder builder = new StringBuilder();

        if (TypeUtil.IsTemplate(definition))
        {
            
            if (definition.GenericParameters.Count > 0)
            {
                builder.Append(FullName);
                builder.Append('<');
                for (int i = 0; i < definition.GenericParameters.Count; i++)
                {
                    builder.Append(definition.GenericParameters[i].FullName);
                    if (i+1 < definition.GenericParameters.Count)
                    {
                        builder.Append(',');
                    }
                }
                builder.Append(">");
                FullName = builder.ToString();                       
            }
        }

    }

    public void RebuildName()
    {
        FullName = Generic.ElementType.FullName;
        StringBuilder builder = new StringBuilder();
        if (Generic.GenericArguments.Count > 0)
        {
            builder.Append(FullName);
            builder.Append('<');
            for (int i = 0; i < Generic.GenericArguments.Count; i++)
            {
                builder.Append(Generic.GenericArguments[i].FullName);
                if (i+1 < Generic.GenericArguments.Count)
                {
                    builder.Append(',');
                }
            }
            builder.Append(">");
            FullName = builder.ToString();                       
        }
    }

    private void TemplateConstructor(TypeDefinition definition)
    {
        Definition = definition;
        FullName = definition.FullName;
        ShortName = definition.Name;
        Descriptor = SectionType.Type;
        Characteristics = Util.CharacteristicsUtil.Parse(definition);
    }
    
    private void DefinitionConstructor(TypeDefinition definition)
    {
        Definition = definition;
        FullName = definition.FullName;
        ShortName = definition.Name;
        Descriptor = SectionType.Type;
        Characteristics = Util.CharacteristicsUtil.Parse(definition);
    }

    private void GenericParameterConstructor(TypeReference reference)
    {
        Reference = reference;
        FullName = reference.FullName;
        ShortName = reference.Name;
        Descriptor = SectionType.Type;         

        Characteristics = Characteristics.Synthetic | Characteristics.Aggregate;
    }

    private void ReferenceConstructor(TypeReference reference)
    {
        Reference = reference;
        FullName = reference.FullName;
        ShortName = reference.Name;
        Descriptor = SectionType.Type;         
        
        Characteristics = Util.CharacteristicsUtil.Parse(reference);            
    }
    
    public Type(TypeDefinition definition)
    {
        if (definition.GenericParameters.Count > 0)
        {
            TemplateConstructor(definition);
        }
        else
        {
            DefinitionConstructor(definition);                        
        }
    }
    
    public Type(Type definition)
    {
        Definition = definition.Definition;
        FullName = definition.FullName;
        ShortName = definition.ShortName;
        Descriptor = SectionType.Type;
        Characteristics = definition.Characteristics;
    }

    public Type(string fullName)
    {
        FullName = fullName;
        string[] spaces = fullName.Split(".");
        ShortName = spaces[spaces.Length - 1];
        Descriptor = SectionType.Type;
        Characteristics = Characteristics.Import;
    }
    
    public override string ToString()
    {
        return $"{FullName}: {Characteristics}";
    }

    public object Clone()
    {
        Type type = new Type();
        return type;
    }

    public override SectionType GetType()
    {
        return Descriptor;
    }
}