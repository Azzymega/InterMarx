﻿using System.Text;
using Internationale.VKP.Serializer.Attributes;
using Mono.Cecil;

namespace Internationale.VKP.Image.Sections;

public class Method : Section, ICloneable
{
    public SectionType Type { get; set; }
    public string FullName 
    {
        get
        {
            if (Owner != null && Return != null)
            {
                StringBuilder builder = new StringBuilder();
                builder.Append(Return.FullName + " " + Owner.FullName + "::" + ShortName);
                builder.Append('(');

                int initialIndex = 1;
                if (Characteristics.HasFlag(Characteristics.Static))
                {
                    initialIndex = 0;
                }
                
                for (int i = initialIndex; i < Parameters.Count; i++)
                {
                    builder.Append(Parameters[i].FullName);
                    if (i+1 < Parameters.Count)
                    {
                        builder.Append(',');
                    }
                }

                builder.Append(')');
                return builder.ToString();
            }

            return null;
        }
    }
    public string ShortName
    {
        get
        {
            if (Definition != null)
            {
                return Definition.Name;
            }
            else if (Reference != null)
            {
                return Reference.Name;
            }

            return null;
        }
    }
    public Characteristics Characteristics { get; set; }
    [Ignore] private Type _owner;
    public Type Owner
    {
        get { return _owner; }
        set
        {
            if (_owner != null)
            {
                _owner.Methods.Remove(this);
            }
            if (value != null)
            {
                value.Subscribe(this);                
            }
            _owner = value;
        }
    }
    public Type Return { get; set; }
    public List<Type> Parameters { get; set; }
    [Ignore] public Executable Executable { get; set; }
    [Ignore] public MethodDefinition Definition { get; set; }
    [Ignore] public MethodReference Reference { get; set; }
    [Ignore] public Method GenericBase { get; set; }

    public object Clone()
    {
        Method method = new Method();

        method.Type = Type;
        method.Characteristics = Characteristics;
        method._owner = _owner;
        method.Return = Return;

        method.Parameters = new List<Type>();
        foreach (var type in Parameters)
        {
            method.Parameters.Add(type);
        }

        method.Definition = Definition;
        method.Reference = Reference;

        return method;
    }

    public void SetOwner(Type owner)
    {
        _owner = owner;
    }
    
    public Method(MethodDefinition definition)
    {
        DefinitionConstructor(definition);
    }

    private Method()
    {
        
    }

    private void DefinitionConstructor(MethodDefinition definition)
    {
        Definition = definition;
        Characteristics = Util.CharacteristicsUtil.Parse(definition);
        
        Type = SectionType.Method;
        Parameters = new List<Type>();

        if (definition.DeclaringType.GenericParameters.Count > 0)
        {
            for (int i = 0; i < definition.DeclaringType.GenericParameters.Count; i++)
            {
                if (definition.DeclaringType.GenericParameters[i] is GenericParameter)
                {
                    Characteristics |= Characteristics.Template;
                }
            }

            if (!Characteristics.HasFlag(Characteristics.Template))
            {
                Characteristics |= Characteristics.Shapeshifter;
            }
        }
    }
    
    private void ReferenceConstructor(MethodReference definition)
    {
        Reference = definition;
        Characteristics = Util.CharacteristicsUtil.Parse(definition);
        Type = SectionType.Method;
        Parameters = new List<Type>();
    }

    public Method(MethodReference definition)
    {
        if (definition is MethodDefinition def)
        {
            DefinitionConstructor(def);
        }
        else
        {
            ReferenceConstructor(definition);
        }
    }
    
    public override string ToString()
    {
        return $"{FullName}: {Characteristics}";
    }

    public override SectionType GetType()
    {
        return Type;
    }
}