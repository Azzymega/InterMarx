﻿using CircularBuffer;
using Internationale.VKP.Serializer.Attributes;

namespace Internationale.VKP.Image.Sections;

public class Strings : Section
{
    public SectionType Type { get; set; }
    public List<string> List { get; set; }

    public Strings()
    {
        Type = SectionType.String;
        List = new List<string>();
    }

    public int Find(string value)
    {
        int index = List.IndexOf(value);
        if (index == -1)
        {
            throw new Exception("String is not found in StringTable of Image!");
        }
        return index;
    }
    
    public int Register(string value)
    {
        int index = List.IndexOf(value);
        if (index == -1)
        {
            List.Add(value);
            return List.Count - 1;
        }
        return index;
    }
    
    public override SectionType GetType()
    {
        return Type;
    }
}