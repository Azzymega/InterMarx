﻿using Internationale.VKP.Serializer.Attributes;
using Mono.Cecil;

namespace Internationale.VKP.Image.Sections;

public class Argument : Section
{
    public SectionType Type { get; set; }
    public Attribute Owner { get; set; }
    public Type Declared { get; set; }
    public List<int> Values { get; set; }
    [Ignore] public CustomAttributeArgument CustomAttributeArgument { get; set; }

    public Argument(CustomAttributeArgument attributeArgument, Attribute owner, Compound.Compound image)
    {
        CustomAttributeArgument = attributeArgument;
        Type = SectionType.Argument;
        Values = new List<int>();
        Owner = owner;
        Declared = image.Get(attributeArgument.Type);

        if (attributeArgument.Value is int value)
        {
            Values.Add(value);
        }
        else if (attributeArgument.Value is string stringValue)
        {
            Values.Add(image.Table.Register(stringValue));
        }
        else if (attributeArgument.Value is CustomAttributeArgument[] arguments)
        {
            foreach (var argument in arguments)
            {
                if (argument.Value is int target)
                {
                    Values.Add(target);
                }
                else
                {
                    throw new ArgumentException(
                        $"Attribute argument with type {attributeArgument.Value.GetType().ToString()} is not supported!");
                }
            }
        }
        else
        {
            throw new ArgumentException(
                $"Attribute argument with type {attributeArgument.Value.GetType().ToString()} is not supported!");
        }
    }
    
    public override SectionType GetType()
    {
        return SectionType.Argument;
    }
}