﻿using Internationale.VKP.Serializer.Attributes;
using Mono.Cecil;

namespace Internationale.VKP.Image.Sections;

public class Attribute : Section
{
    public SectionType Type { get; set; }
    public Section Owner { get; set; }
    public Type Declared { get; set; }
    public Method Constructor { get; set; }
    [Ignore] public CustomAttribute CustomAttribute { get; set; }

    public Attribute(CustomAttribute customAttribute, Section owner, Compound.Compound image)
    {
        CustomAttribute = customAttribute;
        Type = SectionType.Attribute;
        Owner = owner;
        Declared = image.Get(customAttribute.AttributeType);
        Constructor = image.Get(customAttribute.Constructor);
    }
    
    public override SectionType GetType()
    {
        return SectionType.Attribute;
    }

    public override string ToString()
    {
        return $"[{Declared.FullName}] on {Owner.ToString()}";
    }
}