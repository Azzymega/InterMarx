﻿using Internationale.VKP.Image.Code;
using Mono.Cecil.Cil;

namespace Internationale.VKP.Image.Sections;

public class Handler : Section, ICloneable
{    
    public SectionType Type { get; set; }
    public HandlerType HandlerType { get; set; }
    public Type Catch { get; set; }
    public Executable Owner { get; set; }

    public int HandlerStart { get; set; }
    public int HandlerEnd { get; set; }

    public int TryStart { get; set; }
    public int TryEnd { get; set; }

    public object Clone()
    {
        Handler handler = new Handler();

        handler.Type = Type;
        handler.HandlerType = HandlerType;
        handler.Catch = Catch;
        handler.Owner = Owner;
        handler.HandlerStart = HandlerStart;
        handler.HandlerEnd = HandlerEnd;
        handler.TryStart = TryStart;
        handler.TryEnd = TryEnd;

        return handler;
    }

    private Handler()
    {
        
    }
    
    public Handler(Compound.Compound image, ExceptionHandler handler, Executable target, BranchMachine branchMachine)
    {
        Type = SectionType.Handler;
        Owner = target;
        
        switch (handler.HandlerType)
        {
            case ExceptionHandlerType.Catch:
                HandlerType = HandlerType.Catch;
                break;
            case ExceptionHandlerType.Finally:
                HandlerType = HandlerType.Finally;
                break;
            default:
                throw new Exception("Unknown handler type!");
            break;
        }

        if (HandlerType != HandlerType.Finally)
        {
            Catch = image.Get(handler.CatchType);            
        }
        
        HandlerStart = branchMachine.InstructionOffsets[handler.HandlerStart];
        HandlerEnd = branchMachine.InstructionOffsets[handler.HandlerEnd];

        TryStart = branchMachine.InstructionOffsets[handler.TryStart];
        TryEnd = branchMachine.InstructionOffsets[handler.TryEnd];
    }
    
    public override SectionType GetType()
    {
        return SectionType.Handler;
    }
}