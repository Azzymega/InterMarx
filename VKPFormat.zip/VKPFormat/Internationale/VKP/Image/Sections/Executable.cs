﻿using Internationale.VKP.Image.Code;
using Internationale.VKP.Serializer.Attributes;

namespace Internationale.VKP.Image.Sections;

public class Executable : Section, ICloneable
{
    public SectionType Type { get; set; }
    public Method Owner { get; set; }
    public List<SectionType> Types { get; set; }
    public List<Section> Pool { get; set; }
    public List<Type> Variables { get; set; }
    [Extern] public List<string> StringsTable { get; set; }
    [Ignore] public List<Handler> Handlers { get; set; }
    public List<byte> Image { get; set; }

    [Ignore] public List<Bytecode> Bytecodes;

    public object Clone()
    {
        Executable executable = new Executable();

        executable.Type = Type;
        executable.Owner = Owner;
        executable.Types = new List<SectionType>(Types);
        executable.Pool = new List<Section>(Pool);
        executable.Variables = new List<Type>(Variables);
        executable.StringsTable = new List<string>(StringsTable);
        executable.Image = new List<byte>(Image);
        
        return executable;
    }
    
    public Executable()
    {
        Bytecodes = new List<Bytecode>();
        Pool = new List<Section>();
        Types = new List<SectionType>();
        Image = new List<byte>();
        Type = SectionType.Code;
        StringsTable = new List<string>();
        Variables = new List<Type>();
        Handlers = new List<Handler>();
    }

    public override SectionType GetType()
    {
        return Type;
    }

    public override string ToString()
    {
        return $"Executable code for {Owner.FullName}";
    }
    
}