﻿using Internationale.VKP.Image.Util;
using Internationale.VKP.Serializer.Attributes;
using Mono.Cecil;

namespace Internationale.VKP.Image.Sections;

public class Field : Section, ICloneable
{
    public SectionType Type { get; set; }
    public string FullName
    {
        get
        {
            if (Declared != null && Owner != null)
            {
                return Declared.FullName + " " + Owner.FullName + "::" + ShortName;
            }
            return ShortName;
        }
    }
    public string ShortName
    {
        get
        {
            if (Definition != null)
            {
                return Definition.Name;
            }

            if (Reference != null)
            {
                return Reference.Name;
            }

            return null;
        }
    }
    public Characteristics Characteristics { get; set; }
    [Ignore] private Type _owner;
    public Type Owner
    {
        get { return _owner; }
        set
        {
            if (_owner != null)
            {
                _owner.Fields.Remove(this);
            }
            if (value != null)
            {
                value.Subscribe(this);
            }
            _owner = value;
        }
    }
    public Type Declared { get; set; }
    [Ignore] public FieldDefinition Definition { get; set; }
    [Ignore] public FieldReference Reference { get; set; }
    [Ignore] public Field GenericBase { get; set; }

    public void SetOwner(Type type)
    {
        _owner = type;
    }
    
    public object Clone()
    {
        Field field = new Field();
        
        field.Type = Type;
        field.Definition = Definition;
        field.Reference = Reference;
        field._owner = _owner;
        field.Declared = Declared;
        field.Characteristics = Characteristics;

        return field;
    }
    
    public Field(FieldReference reference)
    {
        if (reference is FieldDefinition definition)
        {
            if (definition.ContainsGenericParameter)
            {
                TemplateConstructor(definition);
            }
            else
            {
                DefinitionConstructor(definition);
            }
        }
        else
        {
            ReferenceConstructor(reference);
            if (reference.ContainsGenericParameter)
            {
                if (!Characteristics.HasFlag(Characteristics.Template))
                {
                    Characteristics |= Characteristics.Template;
                }

                if (Characteristics.HasFlag(Characteristics.Shapeshifter))
                {
                    Characteristics ^= Characteristics.Shapeshifter;
                }
            }
        }
    }

    private Field()
    {
        
    }

    public void DefinitionConstructor(FieldDefinition definition)
    {
        Definition = definition;
        Type = SectionType.Field;
        Characteristics = CharacteristicsUtil.Parse(definition);
    }

    public void TemplateConstructor(FieldDefinition definition)
    {
        Definition = definition;
        Type = SectionType.Field;
        Characteristics = CharacteristicsUtil.Parse(definition);

        if (TypeUtil.IsTemplate(definition.DeclaringType) || TypeUtil.IsTemplate(definition.FieldType))
        {
            if (!Characteristics.HasFlag(Characteristics.Template))
            {
                Characteristics |= Characteristics.Template;
            }

            if (Characteristics.HasFlag(Characteristics.Shapeshifter))
            {
                Characteristics ^= Characteristics.Shapeshifter;
            }
        }
    }

    public void ReferenceConstructor(FieldReference definition)
    {
        Reference = definition;
        Type = SectionType.Field;
        Characteristics = CharacteristicsUtil.Parse(definition);
    }

    public override string ToString()
    {
        return $"{FullName}: {Characteristics}";
    }

    public override SectionType GetType()
    {
        return Type;
    }
}