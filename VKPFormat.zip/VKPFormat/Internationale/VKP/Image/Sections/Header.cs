﻿using Internationale.VKP.Serializer.Attributes;

namespace Internationale.VKP.Image.Sections;

public class Header : Section
{
    public SectionType Type { get; set; }
    [Inline]
    public string Identifier { get; set; }
    
    [Inline]
    public string Version { get; set; }

    public Header(string version)
    {
        Type = SectionType.Header;
        Identifier = Guid.NewGuid().ToString();
        Version = version;
    }
    
    public override SectionType GetType()
    {
        return Type;
    }
}