﻿namespace Internationale.VKP.Image;

[Flags]
public enum Characteristics : int
{
    None,
    Private = 1,
    Public = 2,
    Static = 4,
    Internal = 8,
    Abstract = 16,
    Interface = 32,
    Virtual = 64,
    Getter = 128,
    Setter = 256,
    Extern = 512,
    Primitive = 1024,
    Class = 2048,
    Enum = 4096,
    Struct = 8192,
    Constructor = 16384,
    Monitor = 32768,
    Array = 65536,
    Synthetic = 131072,
    Pointer = 262144,
    Aggregate = 524288,
    Sealed = 1048576,
    Import = 2097152,
    Delegate = 4194304,
    Final = 8388608,
    Initialize = 16777216,
    Reference = 33554432,
    Shapeshifter = 67108864,
    Template = 134217728,
    Sequential = 268435456
}