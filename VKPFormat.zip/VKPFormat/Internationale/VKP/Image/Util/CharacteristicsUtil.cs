﻿using Mono.Cecil;

namespace Internationale.VKP.Image.Util;

public class CharacteristicsUtil
{
    public const string MulticastDelegateName = "System.MulticastDelegate";
    public const string DelegateName = "System.Delegate";
    
    public static Characteristics Parse(TypeDefinition definition)
    {
        Characteristics characteristics = Characteristics.None;

        if (definition.IsAbstract)
        {
            characteristics |= Characteristics.Abstract;
        }

        if (definition.IsGenericParameter)
        {
            characteristics |= Characteristics.Aggregate;
        }
        
        if (definition.IsGenericInstance || definition.HasGenericParameters)
        {
            characteristics |= Characteristics.Template;
        }

        if (definition.IsClass)
        {
            characteristics |= Characteristics.Class;
        }

        if (definition.IsInterface)
        {
            characteristics |= Characteristics.Interface;
        }

        if (definition.IsEnum)
        {
            characteristics |= Characteristics.Enum;
        }

        if (definition.BaseType != null)
        {
            if (definition.BaseType.FullName == MulticastDelegateName || definition.BaseType.FullName == DelegateName)
            {
                if (definition.FullName != MulticastDelegateName)
                {
                    characteristics |= Characteristics.Delegate;
                }
            }            
        }
        
        if (definition.IsValueType)
        {
            characteristics |= Characteristics.Struct;
        }

        if (definition.IsPrimitive)
        {
            characteristics |= Characteristics.Primitive;
        }
        
        if (definition.IsImport)
        {
            characteristics |= Characteristics.Import;
        }
        
        if (definition.IsSealed)
        {
            characteristics |= Characteristics.Sealed;
        }

        if (definition.IsPointer)
        {
            characteristics |= Characteristics.Pointer;
        }

        if (definition.IsSequentialLayout)
        {
            characteristics |= Characteristics.Sequential;
        }

        if (definition.IsArray)
        {
            characteristics |= Characteristics.Array;
        }

        bool containsCctor = false;

        foreach (var method in definition.Methods)
        {
            if (method.FullName.Contains(".cctor()"))
            {
                containsCctor = true;
            }
        }

        if (definition.HasCustomAttributes || containsCctor)
        {
            characteristics |= Characteristics.Initialize;
        }

        return characteristics;
    }

    public static Characteristics Parse(GenericInstanceType definition)
    {
        Characteristics characteristics = Characteristics.None;

        if (definition.IsValueType)
        {
            characteristics |= Characteristics.Struct;
        }
        
        if (definition.IsPrimitive)
        {
            characteristics |= Characteristics.Primitive;
        }

        if (definition.IsArray)
        {
            characteristics |= Characteristics.Array;
            characteristics |= Characteristics.Synthetic;
        }
        
        if (!definition.HasGenericParameters && !definition.IsArray && !definition.IsGenericInstance && !definition.IsGenericParameter)
        {
            characteristics |= Characteristics.Import;            
        }
        else
        {
            if (definition.HasGenericParameters)
            {
                characteristics |= Characteristics.Shapeshifter;
            }
        }
        
        return characteristics;
    }
    
    public static Characteristics Parse(TypeReference definition)
    {
        Characteristics characteristics = Characteristics.None;

        if (definition is TypeDefinition def)
        {
            return Parse(def);
        }

        if (definition.IsValueType)
        {
            characteristics |= Characteristics.Struct;
        }
        
        if (definition.IsPrimitive)
        {
            characteristics |= Characteristics.Primitive;
        }
        
        if (definition.IsArray)
        {
            characteristics |= Characteristics.Array;
            characteristics |= Characteristics.Synthetic;
        }
        
        if (definition.GetElementType() is GenericParameter)
        {
            characteristics |= Characteristics.Template;
        }
        
        if (!definition.HasGenericParameters && !definition.IsArray && !definition.IsGenericInstance && !definition.IsGenericParameter)
        {
            characteristics |= Characteristics.Import;            
        }
        else
        {
            if (definition.HasGenericParameters)
            {
                characteristics |= Characteristics.Shapeshifter;
            }
        }
        
        return characteristics;
    }
    
    public static Characteristics Parse(FieldDefinition definition)
    {
        Characteristics characteristics = Characteristics.None;

        if (definition.IsPublic)
        {
            characteristics |= Characteristics.Public;
        }

        if (definition.IsPrivate)
        {
            characteristics |= Characteristics.Private;
        }

        if (definition.ContainsGenericParameter)
        {
            if (!definition.DeclaringType.IsGenericParameter && !definition.FieldType.IsGenericParameter)
            {
                if (!definition.DeclaringType.HasGenericParameters && !definition.FieldType.HasGenericParameters)
                {
                    characteristics |= Characteristics.Shapeshifter;                             
                }
            }
        }

        if (definition.IsStatic)
        {
            characteristics |= Characteristics.Static;
        }
        
        if (definition.HasCustomAttributes)
        {
            characteristics |= Characteristics.Initialize;
        }

        return characteristics;
    }
    
    public static Characteristics Parse(FieldReference definition)
    {
        Characteristics characteristics = Characteristics.None;

        characteristics |= Characteristics.Import;

        return characteristics;
    }
    
    public static Characteristics Parse(MethodReference definition)
    {
        Characteristics characteristics = Characteristics.None;

        characteristics |= Characteristics.Import;

        return characteristics;
    }
    
    public static Characteristics Parse(MethodDefinition definition)
    {
        Characteristics characteristics = Characteristics.None;

        if (definition.IsPublic)
        {
            characteristics |= Characteristics.Public;
        }

        if (definition.HasGenericParameters)
        {
            characteristics |= Characteristics.Shapeshifter;
        }

        if (definition.IsAbstract)
        {
            characteristics |= Characteristics.Abstract;
        }

        if (definition.IsPrivate)
        {
            characteristics |= Characteristics.Private;
        }

        if (definition.IsStatic)
        {
            characteristics |= Characteristics.Static;
        }
        
        if (definition.IsVirtual)
        {
            characteristics |= Characteristics.Virtual;
        }
        
        if (definition.Body == null)
        {
            characteristics |= Characteristics.Extern;
        }
        else if (definition.Body.Instructions.Count == 0)
        {
            characteristics |= Characteristics.Extern;
        }
        
        if (definition.IsConstructor)
        {
            characteristics |= Characteristics.Constructor;
        }
        
        if (definition.IsGetter)
        {
            characteristics |= Characteristics.Getter;
        }
        
        if (definition.IsSetter)
        {
            characteristics |= Characteristics.Setter;
        }
        
        if (definition.IsSynchronized)
        {
            characteristics |= Characteristics.Monitor;
        }

        if (definition.IsFinal)
        {
            characteristics |= Characteristics.Final;
        }

        if (definition.IsSpecialName || definition.IsRuntimeSpecialName)
        {
            characteristics |= Characteristics.Synthetic;
        }
        
        if (definition.HasCustomAttributes)
        {
            characteristics |= Characteristics.Initialize;
        }
        
        return characteristics;
    }
}