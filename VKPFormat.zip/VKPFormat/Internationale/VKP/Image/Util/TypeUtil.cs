﻿using Mono.Cecil;
using Type = Internationale.VKP.Image.Sections.Type;

namespace Internationale.VKP.Image.Util;

public static class TypeUtil
{
    public static bool IsTemplate(GenericInstanceType definition)
    {
        bool isTemplate = false;

        foreach (var parameter in definition.GenericParameters)
        {
            if (parameter is GenericParameter)
            {
                isTemplate = true;
            }
        }

        foreach (var argument in definition.GenericArguments)
        {
            if (argument is GenericParameter)
            {
                isTemplate = true;
            }   
        }
        
        return isTemplate;
    }

    public static bool IsDelegate(TypeDefinition definition)
    {
        if (definition.BaseType == null)
        {
            return false;
        }
        
        if (definition.BaseType.FullName == "System.MulticastDelegate")
        {
            return true;
        }

        return false;
    }
    
    public static bool IsTemplate(TypeDefinition definition)
    {
        bool isTemplate = false;

        foreach (var parameter in definition.GenericParameters)
        {
            if (parameter is GenericParameter)
            {
                isTemplate = true;
            }
        }
        
        return isTemplate;
    }
    
    public static bool IsTemplate(TypeReference definition)
    {
        bool isTemplate = false;

        if (definition.ContainsGenericParameter)
        {
            isTemplate = true;
        }
        
        return isTemplate;
    }
}