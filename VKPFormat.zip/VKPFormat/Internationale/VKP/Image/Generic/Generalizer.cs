﻿using System.Text;
using Internationale.VKP.Image.Sections;
using Mono.Cecil;
using Type = Internationale.VKP.Image.Sections.Type;

namespace Internationale.VKP.Image.Generic;

public class Generalizer
{
    public Image Image { get; set; }
    public Dictionary<Type, Type> Translator { get; set; }

    public Generalizer(Image image)
    {
        Image = image;
    }
    
    public void Generalize()
    {
        foreach (var section in Image.Sections)
        {
            if (section.GetType() == SectionType.Type)
            {
                if (section is Type value)
                {
                    if (value.Characteristics.HasFlag(Characteristics.Shapeshifter))
                    {
                        if (!value.Characteristics.HasFlag(Characteristics.Template) && !value.Characteristics.HasFlag(Characteristics.Array))
                        {
                            Generalize(value);
                        }
                    }
                }
            }
        }
    }

    private void Generalize(Type target)
    {
        Translator = new Dictionary<Type, Type>();

        List<TypeReference> genericArguments = new List<TypeReference>();
        GenericInstanceType instanceType = (GenericInstanceType)target.Reference;
        foreach (var parameter in instanceType.GenericArguments)
        {
            genericArguments.Add(parameter);
        }

        List<GenericParameter> genericParameters = new List<GenericParameter>();
        foreach (var parameter in target.Reference.GetElementType().GenericParameters)
        {
            genericParameters.Add(parameter);
        }

        for (int i = 0; i < genericParameters.Count; i++)
        {
            // Type parameter = Image.Get(genericParameters[i]);
            // Type argument = Image.Get(genericArguments[i]);
            //
            // Translator.Add(parameter,argument);
        }
        
        foreach (var field in target.Fields)
        {
            Generalize(field,target);
        }

        foreach (var method in target.Methods)
        {
            Generalize(method,target);
        }
    }

    private string GenerateName(Field field, Type owner)
    {
        StringBuilder builder = new StringBuilder();

        return builder.ToString();
    }
    
    private string GenerateName(Method field, Type owner)
    {
        StringBuilder builder = new StringBuilder();

        return builder.ToString();
    }

    private void Generalize(Field field, Type owner)
    {

    }
    
    private void Generalize(Method method, Type owner)
    {

    }   
    
}