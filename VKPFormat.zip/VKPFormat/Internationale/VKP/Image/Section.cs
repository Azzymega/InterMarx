﻿namespace Internationale.VKP.Image;

public abstract class Section
{
    public abstract SectionType GetType();
}