﻿// using Internationale.VKP.Image;
// using Internationale.VKP.Image.Sections;
// using Mono.Cecil;
// using Type = Internationale.VKP.Image.Sections.Type;
//
// namespace Internationale.VKP.Internationale.VKP.Generator;
//
// public class FieldLoader
// {
//     private AssemblyDefinition _definition;
//     private Image.Image _image;
//     private List<Image.Sections.Field> _fields;
//     
//     // Optimizations
//
//     private Dictionary<FieldReference, Field> _dictionary;
//
//     public FieldLoader(AssemblyDefinition definition, Image.Image image)
//     {
//         _dictionary = new Dictionary<FieldReference, Field>();
//         _definition = definition;
//         _image = image;
//         _fields = new List<Field>();
//     }
//
//     public void Load()
//     {
//         LoadFields();
//         InspectMethods();
//         
//         _image.Sections.AddRange(_fields);
//     }
//
//     private void AddField(Field field, FieldReference reference)
//     {
//         _dictionary.Add(reference,field);
//         _fields.Add(field);
//     }
//
//     private bool FieldExist(FieldReference reference)
//     {
//         if (_dictionary.ContainsKey(reference))
//         {
//             return true;
//         }
//         
//         // foreach (var field in _fields)
//         // {
//         //     if (reference.FullName == field.FullName)
//         //     {
//         //         return true;
//         //     }
//         // }
//
//         return false;
//     }
//
//     private void InspectMethods()
//     {
//         ModuleDefinition mainModule = _definition.MainModule;
//
//         foreach (var type in mainModule.Types)
//         {
//             foreach (var method in type.Methods)
//             {
//                 if (method.HasBody)
//                 {
//                     foreach (var instruction in method.Body.Instructions)
//                     {
//                         if (instruction.Operand is FieldReference reference)
//                         {
//                             if (!FieldExist(reference))
//                             {
//                                 Field target = new Field(reference);
//
//                                 target.Owner = _image.Get(reference.DeclaringType);
//                                 target.Declared = _image.Get(reference.FieldType);
//                                 
//                                 AddField(target,reference);
//                             }
//                         }
//                     }
//                 }
//             }
//         }
//     }
//     
//     private void LoadFields()
//     {
//         foreach (var section in _image.Sections)
//         {
//             if (section.GetType() == SectionType.Type)
//             {
//                 Type type = (Type)section;
//
//                 if (type.Definition != null)
//                 {
//                     TypeDefinition target = type.Definition;
//
//                     foreach (var metadataField in target.Fields)
//                     {
//                         Field field = new Field(metadataField);
//
//                         field.Declared = _image.Get(metadataField.FieldType);
//                         field.Owner = _image.Get(metadataField.DeclaringType);
//                         
//                         AddField(field,metadataField);
//                     }
//                 }
//                 else if (type.Generic != null)
//                 {
//                     // TODO MAYBE ERROR PLACE!
//                     GenericInstanceType target = type.Generic;
//                 }
//             }
//         }
//     }
// }