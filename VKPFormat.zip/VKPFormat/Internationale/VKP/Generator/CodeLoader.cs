﻿using Mono.Cecil;

namespace Internationale.VKP.Generator;

public class CodeLoader
{
    private AssemblyDefinition _definition;
    private Image.Image _image;

    public CodeLoader(AssemblyDefinition definition, Image.Image image)
    {
        _definition = definition;
        _image = image;
    }

    public void Load()
    {
        Generate();
    }

    public void Generate()
    {
        // ModuleDefinition mainModule = _definition.MainModule;
        //
        // foreach (var type in mainModule.Types)
        // {
        //     if (type.FullName != "<Module>")
        //     {
        //         Type target = _image.Get(type);
        //         foreach (var method in type.Methods)
        //         {
        //             Method info = _image.Get(method);
        //             if (!info.Characteristics.HasFlag(Characteristics.Extern))
        //             {
        //                 ILTranslator writer = new ILTranslator(_image, method, info);
        //                 writer.Compile();
        //                 foreach (var variable in method.Body.Variables)
        //                 {
        //                     info.Executable.Variables.Add(_image.Get(variable.VariableType));
        //                 }
        //             }
        //         }                
        //     }
        // }
    }
}