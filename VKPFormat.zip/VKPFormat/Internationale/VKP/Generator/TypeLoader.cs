﻿using Internationale.VKP.Image;
using Mono.Cecil;
using Mono.Cecil.Rocks;
using Type = Internationale.VKP.Image.Sections.Type;

namespace Internationale.VKP.Generator;

public class TypeLoader
{
    private AssemblyDefinition _definition;
    private Image.Image _image;
    private List<Image.Sections.Type> _types;
    private List<Type> _buffer;

    // Optimization

    private HashSet<TypeReference> _hashSet;

    public TypeLoader(AssemblyDefinition definition, Image.Image image)
    {
        _hashSet = new HashSet<TypeReference>();
        _buffer = new List<Type>();
        _definition = definition;
        _image = image;
        _types = new List<Type>();
    }

    private void Bump()
    {
        List<Type> types = new List<Type>();

        foreach (var type in _buffer)
        {
            bool present = false;
            foreach (var type1 in types)
            {
                if (type.FullName == type1.FullName)
                {
                    present = true;
                }
            }

            if (!present)
            {
                types.Add(type);
            }
        }
        
        _types.AddRange(types);
        _buffer.Clear();
    }

    private void AddType(Type value, TypeReference reference)
    {
        if (IsTypeExists(reference) && !reference.IsArray && !reference.IsPointer && !reference.IsByReference)
        {
            return;
        }

        foreach (var type in _types)
        {
            if (type.Equals(value))
            {
                return;
            }
        }

        foreach (var type in _buffer)
        {
            if (type.Equals(value))
            {
                return;
            }
        }

        _hashSet.Add(reference);
        _buffer.Add(value);
    }
    
    public void Load()
    {
        ModuleDefinition mainModule = _definition.MainModule;

        RegisterTypeSystem(mainModule);

        foreach (var type in mainModule.Types)
        {
            Image.Sections.Type value = new Image.Sections.Type(type);
            AddType(value, type);
        }

        RemoveUnnecessaryInformation();
        LoadImport();
        InspectFields();
        AnalyzeMethods();
        LoadSuper();
        Bump();
        LoadGeneric();
        Bump();
        Sort();

        _image.Sections.AddRange(_types);
    }

    private void LoadGeneric()
    {
        foreach (var type in _types)
        {
            if (type.Generic != null)
            {
                type.Base = LocateType(type.Generic.ElementType);
            }
        }
    }

    private void AnalyzeMethods()
    {
        foreach (var type in ModuleDefinitionRocks.GetAllTypes(_definition.MainModule))
        {
            foreach (var method in TypeDefinitionRocks.GetMethods(type))
            {
                AddType(new Type(method.ReturnType),method.ReturnType);
                AddType(new Type(method.DeclaringType),method.DeclaringType);

                foreach (var parameter in method.Parameters)
                {
                    AddType(new Type(parameter.ParameterType),parameter.ParameterType);
                }
                
                if (method.HasBody)
                {
                    foreach (var variable in method.Body.Variables)
                    {
                        AddType(new Type(variable.VariableType),variable.VariableType);
                    }
                    
                    foreach (var instruction in method.Body.Instructions)
                    {
                        if (instruction.Operand is TypeReference typeReference)
                        {
                            AddType(new Type(typeReference),typeReference);
                        }   
                    }
                }
                
                Bump();
            }
        }
    }
    
    private void InspectMethods()
    {
        ModuleDefinition mainModule = _definition.MainModule;

        Start:
        bool allocated = false;

        foreach (var typesType in _types)
        {
            if (typesType.Definition == null)
            {
                continue;
            }

            foreach (var method in typesType.Definition.Methods)
            {
                if (!IsTypeExists(method.DeclaringType))
                {
                    AddType(new Type(method.DeclaringType), method.DeclaringType);
                    allocated = true;
                }

                if (!IsTypeExists(method.ReturnType))
                {
                    AddType(new Type(method.ReturnType), method.ReturnType);
                    allocated = true;
                }

                foreach (var definition in method.Parameters)
                {
                    if (!IsTypeExists(definition.ParameterType))
                    {
                        AddType(new Type(definition.ParameterType), definition.ParameterType);
                        allocated = true;
                    }
                }

                if (method.HasBody)
                {
                    foreach (var variable in method.Body.Variables)
                    {
                        if (!IsTypeExists(variable.VariableType))
                        {
                            AddType(new Type(variable.VariableType), variable.VariableType);
                            allocated = true;
                        }
                    }

                    foreach (var instruction in method.Body.Instructions)
                    {
                        if (instruction.Operand is TypeReference reference)
                        {
                            if (!IsTypeExists(reference))
                            {
                                AddType(new Type(reference), reference);
                                allocated = true;
                            }
                        }
                        else if (instruction.Operand is TypeDefinition definition)
                        {
                            if (!IsTypeExists(definition))
                            {
                                AddType(new Type(definition), definition);
                                allocated = true;
                            }
                        }
                        else if (instruction.Operand is FieldReference fieldReference)
                        {
                            if (!IsTypeExists(fieldReference.FieldType))
                            {
                                AddType(new Type(fieldReference.FieldType), fieldReference.FieldType);
                                allocated = true;
                            }

                            if (!IsTypeExists(fieldReference.DeclaringType))
                            {
                                AddType(new Type(fieldReference.DeclaringType), fieldReference.DeclaringType);
                                allocated = true;
                            }
                        }
                        else if (instruction.Operand is MethodReference methodReference)
                        {
                            if (!IsTypeExists(methodReference.ReturnType))
                            {
                                AddType(new Type(methodReference.ReturnType), methodReference.ReturnType);
                                allocated = true;
                            }

                            if (!IsTypeExists(methodReference.DeclaringType))
                            {
                                AddType(new Type(methodReference.DeclaringType), methodReference.DeclaringType);
                                allocated = true;
                            }

                            foreach (var parameter in methodReference.Parameters)
                            {
                                if (!IsTypeExists(parameter.ParameterType))
                                {
                                    AddType(new Type(parameter.ParameterType), parameter.ParameterType);
                                    allocated = true;
                                }
                            }
                        }
                        else if (instruction.Operand is FieldDefinition fieldDefinition)
                        {
                            if (!IsTypeExists(fieldDefinition.FieldType))
                            {
                                AddType(new Type(fieldDefinition.FieldType), fieldDefinition.FieldType);
                                allocated = true;
                            }

                            if (!IsTypeExists(fieldDefinition.DeclaringType))
                            {
                                AddType(new Type(fieldDefinition.DeclaringType), fieldDefinition.DeclaringType);
                                allocated = true;
                            }
                        }
                    }
                }
            }
        }

        if (allocated)
        {
            Bump();
            goto Start;
        }

        Bump();
    }

    private bool IsTypeExists(TypeReference reference)
    {
        if (_hashSet.Contains(reference))
        {
            return true;
        }

        // foreach (var type in _types)
        // {
        //     if (type.FullName == reference.FullName)
        //     {
        //         return true;
        //     }
        // }

        return false;
    }

    private Type LocateType(TypeReference reference)
    {
        foreach (var type in _types)
        {
            if (type.Definition != null)
            {
                if (type.Definition == reference)
                {
                    return type;
                }
            }

            if (type.Generic != null)
            {
                if (type.Generic == reference)
                {
                    return type;
                }
            }

            if (type.Reference != null)
            {
                if (type.Reference == reference)
                {
                    return type;
                }
            }
        }

        throw new ArgumentException($"Type {reference.FullName} is not found!");
    }

    private void InspectFields()
    {
        ModuleDefinition mainModule = _definition.MainModule;
        
        bool allocated = false;

        foreach (var type in ModuleDefinitionRocks.GetAllTypes(_definition.MainModule))
        {
            foreach (var field in type.Fields)
            {
                AddType(new Type(field.DeclaringType), field.DeclaringType);
                AddType(new Type(field.FieldType), field.FieldType);
            }
            Bump();
        }
    }

    private void RemoveUnnecessaryInformation()
    {
        for (int i = 0; i < _types.Count; i++)
        {
            if (_types[i].FullName == "<Module>")
            {
                _types.Remove(_types[i]);
            }
        }
    }

    private void RegisterTypeSystem(ModuleDefinition main)
    {
        AddType(new Type(main.TypeSystem.Boolean), main.TypeSystem.Boolean);
        AddType(new Type(main.TypeSystem.Char), main.TypeSystem.Char);
        AddType(new Type(main.TypeSystem.Object), main.TypeSystem.Object);
        AddType(new Type(main.TypeSystem.Byte), main.TypeSystem.Byte);
        AddType(new Type(main.TypeSystem.Double), main.TypeSystem.Double);
        AddType(new Type(main.TypeSystem.Int16), main.TypeSystem.Int16);
        AddType(new Type(main.TypeSystem.Int32), main.TypeSystem.Int32);
        AddType(new Type(main.TypeSystem.Int64), main.TypeSystem.Int64);
        AddType(new Type(main.TypeSystem.Single), main.TypeSystem.Single);
        AddType(new Type(main.TypeSystem.String), main.TypeSystem.String);
        AddType(new Type(main.TypeSystem.Void), main.TypeSystem.Void);
        AddType(new Type(main.TypeSystem.SByte), main.TypeSystem.SByte);
        AddType(new Type(main.TypeSystem.UInt16), main.TypeSystem.UInt16);
        AddType(new Type(main.TypeSystem.UInt32), main.TypeSystem.UInt32);
        AddType(new Type(main.TypeSystem.UInt64), main.TypeSystem.UInt64);
        AddType(new Type(main.TypeSystem.UIntPtr), main.TypeSystem.UIntPtr);
        AddType(new Type(main.TypeSystem.IntPtr), main.TypeSystem.IntPtr);
        AddType(new Type(main.TypeSystem.TypedReference), main.TypeSystem.TypedReference);
    }

    private void LoadSuper()
    {
        for (int i = 0; i < _types.Count; i++)
        {
            Type value = _types[i];

            if (value.FullName == "System.Object")
            {
                return;
            }

            if (!value.Characteristics.HasFlag(Characteristics.Import))
            {
                if (IsTypeExists(value.Definition.BaseType))
                {
                    value.Base = LocateType(value.Definition.BaseType);
                }
                else
                {
                    Type target = new Type(value.Definition.BaseType);
                    value.Base = target;
                    AddType(target, value.Definition.BaseType);
                }
            }
        }
    }

    private void LoadImport()
    {
        for (int i = 0; i < _types.Count; i++)
        {
            Type initial = _types[i];
            for (int j = 0; j < _types.Count; j++)
            {
                Type second = _types[j];
                if (i != j && initial.FullName == second.FullName)
                {
                    if (initial.Characteristics.HasFlag(Characteristics.Import))
                    {
                        _types.Remove(initial);
                        i--;
                        break;
                    }

                    if (second.Characteristics.HasFlag(Characteristics.Import))
                    {
                        _types.Remove(second);
                        i--;
                        break;
                    }

                    _types.Remove(second);
                    i--;
                    break;
                }
            }
        }
    }

    private void Sort()
    {
        Base:
        for (int i = 0; i < _types.Count; i++)
        {
            Type target = _types[i];
            Type super = target.Base;

            if (super != null)
            {
                int superIndex = _types.IndexOf(super);
                if (superIndex > i)
                {
                    _types[i] = super;
                    _types[superIndex] = target;
                    goto Base;
                }
            }
        }
    }
}