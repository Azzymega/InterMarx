﻿// using Internationale.VKP.Image;
// using Internationale.VKP.Image.Sections;
// using Mono.Cecil;
// using Type = Internationale.VKP.Image.Sections.Type;
//
// namespace Internationale.VKP.Internationale.VKP.Generator;
//
// public class MethodLoader
// {
//     private AssemblyDefinition _definition;
//     private Image.Image _image;
//     private List<Image.Sections.Method> _methods;
//     
//     // Optimization
//
//     private Dictionary<MethodReference, Method> _dictionary;
//     
//     public MethodLoader(AssemblyDefinition definition, Image.Image image)
//     {
//         _dictionary = new Dictionary<MethodReference, Method>();
//         _definition = definition;
//         _image = image;
//         _methods = new List<Method>();
//     }
//     
//     public void Load()
//     {
//         LoadMethods();
//         InspectMethods();
//         
//         _image.Sections.AddRange(_methods);
//     }
//
//     private void AddMethod(Method method, MethodReference methodReference)
//     {
//         _methods.Add(method);
//         _dictionary.Add(methodReference,method);
//     }
//     
//     private void InspectMethods()
//     {
//         ModuleDefinition mainModule = _definition.MainModule;
//
//         foreach (var type in mainModule.Types)
//         {
//             foreach (var method in type.Methods)
//             {
//                 if (method.HasBody)
//                 {
//                     foreach (var instruction in method.Body.Instructions)
//                     {
//                         if (instruction.Operand is MethodReference reference)
//                         {
//                             if (!IsMethodExist(reference))
//                             {
//                                 Method methodTarget = new Method(reference);
//
//                                 methodTarget.Return = _image.Get(reference.ReturnType);
//                                 methodTarget.Owner = _image.Get(reference.DeclaringType);
//
//                                 foreach (var parameter in reference.Parameters)
//                                 {
//                                     methodTarget.Parameters.Add(_image.Get(parameter.ParameterType));
//                                 }
//                             
//                                 AddMethod(methodTarget,reference);                           
//                             }
//                         }
//                     }
//                 }
//             }
//         }
//     }
//
//     private bool IsMethodExist(MethodReference reference)
//     {
//         if (_dictionary.ContainsKey(reference))
//         {
//             return true;
//         }
//         
//         // foreach (var method in _methods)
//         // {
//         //     if (method.FullName == reference.FullName)
//         //     {
//         //         return true;
//         //     }
//         // }
//
//         return false;
//     }
//
//     private void LoadMethods()
//     {
//         foreach (var section in _image.Sections)
//         {
//             if (section.GetType() == SectionType.Type)
//             {
//                 Type type = (Type)section;
//
//                 if (type.Definition != null)
//                 {
//                     TypeDefinition target = type.Definition;
//
//                     foreach (var metadataMethod in target.Methods)
//                     {
//                         Method method = new Method(metadataMethod);
//
//                         method.Return = _image.Get(metadataMethod.ReturnType);
//                         method.Owner = _image.Get(metadataMethod.DeclaringType);
//                         
//                         foreach (var parameter in metadataMethod.Parameters)
//                         {
//                             method.Parameters.Add(_image.Get(parameter.ParameterType));
//                         }
//                         
//                         AddMethod(method,metadataMethod);
//                     }
//                 }
//             }
//         }
//     }
//
// }